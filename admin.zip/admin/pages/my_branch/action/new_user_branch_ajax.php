<?php 

$path = preg_replace('/accounts.*$/','',__DIR__);
include($path.'wp-load.php');

$request_body = file_get_contents('php://input');
$data = json_decode($request_body);
print_r($data);

// if (username_exists($data->user_mobile)){
// 	echo '<div class="alert alert-danger" role="alert">حساب دیگری در وب سایت با شماره تماس مد نظر شما وجود دارد . لطفا شماره ای را انتخاب کنید که پیشتر در سیستم وجود نداشته باشد.</div>';
// 	$html ='<div class="mbcu_submit col-12">';
// 		$html .='<a class="btn btn-success" href="'.get_site_url().'/my-account/?admin=new_leasing_user">ثبت کارمند جدید</a>';
// 	$html .='</div>';
// 	echo $html;
// }else{
	

// 	$uname = $data->first_name . ' ' .$data->last_name ; 
	// $user_id = wp_insert_user(
	// 	[
	// 		'user_pass'=>$data->user_mobile,
	// 		'user_login'=>$data->user_mobile,
	// 		'user_nicename'=>$data->$uname,
	// 		'display_name'=>$data->$uname,
	// 		'nickname'=>$data->$uname,
	// 		'first_name'=>$data->first_name,
	// 		'last_name'=>$data->last_name,
	// 		'show_admin_bar_front'=>false,
	// 		'role'=>'leasing'
	// 	]
	// );
	// if (! is_wp_error( $user_id ) ){
	// 	echo '<div class="alert alert-success" role="alert">تبریک . حساب کاربری شما ایجاد شد .</div>';
	// 	echo '<div class="alert alert-info" role="alert">شماره موبایل کاربر : '.$data->user_mobile."\n رمز عبور همان شماره تماس خواهد بود".'</div>';
	// }else{
	// 	echo '<div class="alert alert-warning" role="alert">به دلایل نامعلوم ثبت کاربر انجام نگردید.</div>';
	// 	$html ='<div class="mbcu_submit col-12">';
	// 		$html .='<a class="btn btn-success" href="'.get_site_url().'/my-account/?admin=new_leasing_user">ثبت کارمند جدید</a>';
	// 	$html .='</div>';
	// 	echo $html;
	// }
// }