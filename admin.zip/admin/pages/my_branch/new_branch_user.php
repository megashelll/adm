<?php 
global $wpdb;
$t1 = $wpdb->prefix . 'terms';
$t2 = $wpdb->prefix . 'term_taxonomy';
$sql = "SELECT B.term_id, B.name FROM `edu_term_taxonomy` as A 
        INNER JOIN `edu_terms` AS B on A.term_id = B.term_id 
        WHERE A.parent='0' and A.taxonomy='state_city';";
$states = $wpdb->get_results($sql);
?>

<div class="container-fluid py-4">
    <!-- Main Card -->
    <div class="card shadow-sm">
        <!-- Card Header -->
        <div class="card-header bg-light py-3">
            <div class="d-flex align-items-center">
                <i class="bi bi-shop me-2 fs-4"></i>
                <div>
                    <h5 class="mb-0">افزودن نمایندگی (عاملیت فروش)</h5>
                    <small class="text-muted"><?php echo get_bloginfo('name'); ?></small>
                </div>
            </div>
        </div>

        <!-- Card Body -->
        <div class="card-body">
            <form class="row g-4">
                <!-- Personal Information Section -->
                <div class="col-12">
                    <div class="d-flex align-items-center mb-3">
                        <i class="bi bi-person-vcard me-2"></i>
                        <h6 class="mb-0">اطلاعات شخصی</h6>
                    </div>
                </div>

                <!-- First Name -->
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" 
                               class="form-control" 
                               id="branchFirstName" 
                               name="branch_first_name" 
                               placeholder="نام"
                               required>
                        <label for="branchFirstName">
                            نام
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <!-- Last Name -->
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" 
                               class="form-control" 
                               id="branchLastName" 
                               name="branch_last_name" 
                               placeholder="نام خانوادگی"
                               required>
                        <label for="branchLastName">
                            نام خانوادگی
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <!-- National ID -->
                <div class="col-12">
                    <div class="form-floating">
                        <input type="text" 
                               class="form-control" 
                               id="branchIdNumber" 
                               name="branch_id_number" 
                               placeholder="کد ملی"
                               maxlength="10"
                               required>
                        <label for="branchIdNumber">
                            کد ملی نماینده
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <div class="col-12"><hr></div>

                <!-- Location Section -->
                <div class="col-12">
                    <div class="d-flex align-items-center mb-3">
                        <i class="bi bi-geo-alt me-2"></i>
                        <h6 class="mb-0">اطلاعات مکانی</h6>
                    </div>
                </div>

                <!-- State -->
                <div class="col-md-6">
                    <div class="form-floating">
                        <select class="form-select" 
                                id="branchState" 
                                name="branch_state" 
                                required 
                                onchange="changes_the_state_cities(jQuery(this).val());">
                            <option value="" selected disabled>استان مورد نظر خود را انتخاب کنید</option>
                            <?php foreach($states as $stat): ?>
                                <option value="<?php echo $stat->term_id; ?>"><?php echo $stat->name; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <label for="branchState">
                            استان
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <!-- City -->
                <div class="col-md-6">
                    <div class="form-floating">
                        <select class="form-select" 
                                id="branchCity" 
                                name="branch_city" 
                                required>
                            <option value="" selected disabled>شهر مورد نظر خود را انتخاب کنید</option>
                        </select>
                        <label for="branchCity">
                            شهر
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <!-- Address -->
                <div class="col-12">
                    <div class="form-floating">
                        <input type="text" 
                               class="form-control" 
                               id="branchAddress" 
                               name="branch__address" 
                               placeholder="آدرس فروشگاه"
                               required>
                        <label for="branchAddress">
                            آدرس فروشگاه
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <!-- Postal Code -->
                <div class="col-12">
                    <div class="form-floating">
                        <input type="text" 
                               class="form-control" 
                               id="branchPostalCode" 
                               name="branch_zip_postal_code" 
                               placeholder="کد پستی"
                               maxlength="10"
                               required>
                        <label for="branchPostalCode">
                            کد پستی فروشگاه
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <div class="col-12"><hr></div>

                <!-- Contact Section -->
                <div class="col-12">
                    <div class="d-flex align-items-center mb-3">
                        <i class="bi bi-telephone me-2"></i>
                        <h6 class="mb-0">اطلاعات تماس</h6>
                    </div>
                </div>

                <!-- Phone -->
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="tel" 
                               class="form-control" 
                               id="branchPhone" 
                               name="branch_phone" 
                               placeholder="تلفن ثابت"
                               required>
                        <label for="branchPhone">
                            تلفن ثابت فروشگاه
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <!-- Mobile -->
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="tel" 
                               class="form-control" 
                               id="branchMobile" 
                               name="branch_mobile" 
                               placeholder="تلفن همراه"
                               maxlength="11"
                               required>
                        <label for="branchMobile">
                            تلفن همراه نماینده
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <!-- Contract Info Section -->
                <div class="col-12">
                    <div class="d-flex align-items-center mb-3">
                        <i class="bi bi-file-text me-2"></i>
                        <h6 class="mb-0">اطلاعات قرارداد</h6>
                    </div>
                </div>

                <!-- Contract Code -->
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" 
                               class="form-control" 
                               id="branchContractSerial" 
                               name="branch_contract_serial" 
                               placeholder="کد قرارداد"
                               required>
                        <label for="branchContractSerial">
                            کد قرارداد
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <!-- Branch Code -->
                <div class="col-md-6">
                    <div class="form-floating">
                        <input type="text" 
                               class="form-control" 
                               id="branchSerialNumber" 
                               name="branch_serial_number" 
                               placeholder="کد نمایندگی"
                               required>
                        <label for="branchSerialNumber">
                            کد شش رقمی نمایندگی
                            <span class="text-danger">*</span>
                        </label>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="col-12 text-end">
                    <hr class="my-4">
                    <button type="button" 
                            class="btn btn-primary d-inline-flex align-items-center" 
                            onclick="add_new_branch_ajax('<?php echo get_current_user_id(); ?>')">
                        <i class="bi bi-check2-circle me-2"></i>
                        ثبت نام نمایندگی
                    </button>
                </div>
            </form>

            <!-- Results Container -->
            <div id="branch-registration-results" class="mt-3"></div>
        </div>
    </div>
</div>

<style>
/* Form Styling */
.form-floating > .form-control {
    height: calc(3.5rem + 2px);
    line-height: 1.25;
}

.form-floating > label {
    padding: 1rem 0.75rem;
    color: #6c757d;
}

/* Section Headers */
h6 {
    color: #495057;
    font-weight: 500;
}

/* Required Field Indicator */
.text-danger {
    font-weight: bold;
    margin-right: 4px;
}

/* Card Styling */
.card {
    border: none;
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .form-floating > .form-control {
        height: calc(3.2rem + 2px);
    }
    
    .form-floating > label {
        padding: 0.8rem 0.75rem;
    }
}
</style>

<script>
// Initialize Select2 for dropdowns (if needed)
$(document).ready(function() {
    // Initialize Select2
    $('.form-select').select2({
        theme: 'bootstrap-5',
        width: '100%'
    });
});
</script>
<?php
?>