<?php 
global $wpdb;
global $woocommerce;

$t1 = $wpdb->prefix . 'users';
$t2 = $wpdb->prefix . 'usermeta';

$user_id = get_current_user_id();

$sql = "SELECT B.user_id FROM `{$t1}` AS A INNER JOIN `{$t2}` AS B ON A.ID = B.meta_value WHERE B.meta_key='branch_leasing_employee_id';";
$branches = $wpdb->get_results($sql);

?>
<div class="container-fluid my-4">
    <div class="card shadow-sm">
        <div class="card-header bg-light py-3">
            <h5 class="mb-0">Branch List</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle" id="all_branch_list">
                    <thead class="table-light">
                        <tr>
                            <th>ردیف.</th>
                            <th>نام</th>
                            <th>شناسه</th>
                            <th>شماره تماس</th>
                            <th>مشتریان</th>
                            <th>سفارشات</th>
                            <th>فروش</th>
                            <th>ویرایش </th>
                            <th>مشاهده مشتریان</th>
                            <th>حذف</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center" id="pagination">
                </ul>
            </nav>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    var currentPage = 1;
    var itemsPerPage = 10;
    var totalItems = <?php echo count($branches); ?>;

    function loadBranchData(page) {
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'load_branch_data',
                page: page,
                items_per_page: itemsPerPage
            },
            success: function(response) {
                $('#all_branch_list tbody').html(response);
                updatePagination(page, Math.ceil(totalItems / itemsPerPage));
            },
            error: function(xhr, status, error) {
                console.error('Error loading data:', error);
            }
        });
    }

    function updatePagination(currentPage, totalPages) {
        var $pagination = $('#pagination');
        $pagination.empty();
        
        if (totalPages <= 1) return;

        // Add "First Page" button
        $pagination.append(`
            <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="1">اولین</a>
            </li>
        `);

        // Add "Previous" button
        $pagination.append(`
            <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${currentPage - 1}">قبلی</a>
            </li>
        `);

        function addPageNumber(pageNum) {
            $pagination.append(`
                <li class="page-item ${pageNum === currentPage ? 'active' : ''}">
                    <a class="page-link" href="#" data-page="${pageNum}">${pageNum}</a>
                </li>
            `);
        }

        // Calculate the range of pages to show
        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(totalPages, startPage + 3);
        
        // Adjust startPage if we're near the end
        if (endPage - startPage < 3) {
            startPage = Math.max(1, endPage - 3);
        }

        // Show first page if there's a gap
        if (startPage > 1) {
            addPageNumber(1);
            if (startPage > 2) {
                $pagination.append(`
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                `);
            }
        }

        // Add page numbers
        for (let i = startPage; i <= endPage; i++) {
            addPageNumber(i);
        }

        // Show last page if there's a gap
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                $pagination.append(`
                    <li class="page-item disabled">
                        <span class="page-link">...</span>
                    </li>
                `);
            }
            addPageNumber(totalPages);
        }

        // Add "Next" button
        $pagination.append(`
            <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${currentPage + 1}">بعدی</a>
            </li>
        `);

        // Add "Last Page" button
        $pagination.append(`
            <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                <a class="page-link" href="#" data-page="${totalPages}">آخرین</a>
            </li>
        `);
    }

    $(document).on('click', '#pagination a', function(e) {
        e.preventDefault();
        var page = $(this).data('page');
        var totalPages = Math.ceil(totalItems / itemsPerPage);
        
        // Check if the link is not disabled
        if ($(this).parent().hasClass('disabled')) {
            return;
        }

        // Validate page number
        if (page >= 1 && page <= totalPages) {
            currentPage = page;
            loadBranchData(currentPage);
            
            // Scroll to top of table if needed
            $('#all_branch_list').get(0).scrollIntoView({ behavior: 'smooth' });
        }
    });

    // Initial load
    loadBranchData(currentPage);
});
</script>
