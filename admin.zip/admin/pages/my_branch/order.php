<?php

global $wpdb;
global $mega_admin;
$html = '';
if (isset($_GET)){
	if (isset($_GET['leasing'])){
		if ($_GET['leasing'] == 'order'){
			$order = wc_get_order($_GET['order_id']);
			if (isset($_GET['plan_id'])){
				$palan_precent 		= get_post_meta($_GET['plan_id'] , 'Interest_rate' , true);
				$banck_account 		= get_post_meta($_GET['plan_id'] , 'bank_account' ,true);
				$shaba_account 		= get_post_meta($_GET['plan_id'] , 'shaba_account' ,true);
				$banck_branch_code 	= get_post_meta($_GET['plan_id'] , 'banck_branch_code' ,true);
				$bank_name 			= get_post_meta($_GET['plan_id'] , 'bank_name' ,true);
				
			}
			
			$now = new DateTime($order->get_date_created());
			$formatter = new IntlDateFormatter(
							"fa_IR@calendar=persian", 
							IntlDateFormatter::FULL, 
								IntlDateFormatter::FULL, 
							'Asia/Tehran', 
							IntlDateFormatter::TRADITIONAL, 
							"yyyy/MM/dd");


			$html .= '<div id="printarea" style="display: block !important;width: 100% !important; font-size:12px;" >';
				$html .='<table style="margin: 0px 0px 5px 0px ; width:100%">';
					$html .='<tr style="border:none;">';
						$html .='<td style="text-align: center;vertical-align: middle;padding: 0px; border: none;">';
							$html .='<h2 style="margin: 0px;">پیش فاکتور</h2>';
						$html .='</td>';
						$html .='<td style="text-align: center;vertical-align: middle;padding: 0px; border: none;">';
							$html .='<span>وب سایت  : '.get_site_url() .'</span>';
						$html .='</td>';
						$html .='<td style="text-align: center;vertical-align: middle;padding: 0px; border: none;">';
						$html .='<div>';
							$html .='<div><span>تاریخ : '.$formatter->format($now).'</span></div>';
							$html .= '<div><span>شماره : '.$_GET['order_id'].'</span></div>';
						$html .='</div>';
						$html .='</td>';
					$html .='</tr>';
				$html .='</table>';
				
				$html .='<div class="shop_informaition d-flex flex-wrap">';
					$html .='<div class="col-4">';
						$html .='<span><strong>نام فروشگاه : </strong></span><span>همتا صنعت ویرا</span>';
					$html .='</div>';
					$html .='<div  class="col-3">';
						$html .='<span><strong>تلفن : </strong></span><span>۰۲۱۷۳۶۷۱۹۱۹</span>';
					$html .='</div>';
					$html .='<div  class="col-3">';
						$html .='<span><strong>ایمیل : </strong></span><span>info@hamtaloans.com</span>';
					$html .='</div>';

					$html .='<div  class="col-12">';
						$html .='<span><strong>آدرس فروشگاه : </strong></span><span>تهران - خیابان شریعتی - قلهک - مجتمع تجاری قلهک - طبقه نهم .</span>';
					$html .='</div>';
					$html .='<div  class="col-12">';
						if ($bank_name != ''){$html .='<span><strong>نام بانک : </strong></span><span>'.$bank_name.'</span> ';}
						if ($banck_account != ''){$html .='<span><strong>شماره حساب : </strong></span><span>'.$banck_account.'</span> ';}
						if ($banck_branch_code != ''){$html .='<span><strong>کد شعبه : </strong></span><span>'.$banck_branch_code.'</span> ';}
						
					$html .='</div>';
				$html .='</div>';

				$html .='<div class="customer_informaition d-flex flex-wrap">';
					$html .='<div class="cust_infor_title col-12">';
						$html .='اطلاعات مشتری';
					$html .='</div>';
					$html .='<div class="invoice_mega_name col-3">';
						$html .='<span><strong>نام و نام خانوادگی   : </strong></span><span>'.get_user_meta($_GET['customer_id'] , 'first_name' , true).' '.get_user_meta($_GET['customer_id'] , 'last_name' , true).'</span>';
					$html .='</div>';
					$html .='<div class="invoice_mega_name col-3">';
						$html .='<span><strong>کد ملی : </strong></span><span>'.get_user_meta($_GET['customer_id'] , 'user_id_number' , true).'</span>';
					$html .='</div>';
					$html .='<div class="invoice_mega_name col-3">';
						$html .='<span><strong>موبایل : </strong></span><span>'.get_user_meta($_GET['customer_id'] , 'user_phone_number' , true).'</span>    ';
					$html .='</div>';
					$html .='<div class="invoice_mega_name col-3">';
						$html .='<span><strong>تلفن: </strong></span><span>'.get_user_meta($_GET['customer_id'] , 'user_phone' , true).'</span>';
					$html .='</div>';
					$html .='<div class="invoice_mega_name col-6">';
						$html .='<span><strong>آدرس : </strong></span><span>'.get_user_meta($_GET['customer_id'] , 'user_address' , true).'</span>';
					$html .='</div>';
					$html .='<div class="invoice_mega_name col-3">';
						$html .='<span><strong>کد پستی : </strong></span><span>'.get_user_meta($_GET['customer_id'] , 'zip_postal_code' , true).'</span>';
					$html .='</div>';
					$html .='<div class="invoice_mega_name col-3 p-0">';
						$branch_id = get_user_meta($_GET['customer_id'] , 'maker_branch_id' , true);

						$table_name = $wpdb->prefix .'branch_customers';
						$cuid = $_GET['customer_id'];
						$sql_ship = "SELECT COUNT(ID) AS BB FROM {$table_name} AS A WHERE A.branch_id = {$branch_id} AND A.customer_id = {$cuid};";
						$counterx = $wpdb->get_results($sql_ship);
						// print_r($counterx[0]->BB);
						$aaa = '';
						if (intval($counterx[0]->BB) == 0){
							$aaa = '00';
						}elseif (intval($counterx[0]->BB) < 10){
							$aaa = '0'.$counterx[0]->BB;
						}elseif (intval($counterx[0]->BB) >= 10 & intval($counterx) <100 ){
							$aaa = $counterx[0]->BB;
						}else{
							if (intval($counterx[0]->BB - 99) == 0){
								$aaa = '00';
							}elseif (intval($counterx[0]->BB -99) < 10){
								$aaa = '0'.intval($counterx[0]->BB -99);
							}elseif (($counterx[0]->BB -99) > 10 & ($counterx[0]->BB -99) <100 ){
								$aaa = ($counterx[0]->BB -99);
							}
						}
								
						$bbcode = get_user_meta($branch_id , 'branch_serial_number' , true).get_user_meta($_GET['customer_id'] , 'user_id_number' , true).$aaa;

						$alp = intval(
							(intval($bbcode[0])*3)+
							(intval($bbcode[1])*5)+
							(intval($bbcode[2])*7)+
							(intval($bbcode[3])*11)+
							(intval($bbcode[4])*13)+
							(intval($bbcode[5])*17)+
							(intval($bbcode[6])*19)+
							(intval($bbcode[7])*23)+
							(intval($bbcode[8])*29)+
							(intval($bbcode[9])*31)+
							(intval($bbcode[10])*37)+
							(intval($bbcode[11])*41)+
							(intval($bbcode[12])*43)+
							(intval($bbcode[13])*47)+
							(intval($bbcode[14])*49)+
							(intval($bbcode[15])*53)+
							(intval($bbcode[16])*59)+
							(intval($bbcode[17])*61)
						);
 
						
						$alp_query="SELECT MOD({$alp},99) as moooood;";
						$alp_data = $wpdb -> get_results($alp_query);


						if (strlen($alp_data[0]->moooood) == 1){
							$exalp = '0' .$alp_data[0]->moooood;
						}elseif(strlen($alp_data[0]->moooood) == 2){
							$exalp = $alp_data[0]->moooood;
						}

						$html .='<span alp="'.$alp.'" b_code="'.$bbcode.'" alp_query="'.$alp_data[0]->moooood.'" aaa="'.$aaa.'"><strong>شناسه واریز : </strong></span><span>'.$bbcode.$exalp.'</span>';

					$html .='</div>';
				$html .='</div>';

				$html .='<div class="mega_invoice_title d-flex">';
					$html .='<h2>شرح کالا</h2>';
				$html .='</div>';
				$html .='<table class="mega_invoice_table">';
					$html .='<thead class="mega_invoice_thead">';
						$html .='<tr class="mega_invoice_th_tr">';
							$html .='<th class="mega_invoice_th_tr_td"  style="padding: 5px;font-size: 13px;">ردیف</th>';
							$html .='<th class="mega_invoice_th_tr_td" style="padding: 5px;font-size: 13px;">عنوان</th>';
							$html .='<th class="mega_invoice_th_tr_td" style="padding: 5px;font-size: 13px;">تعداد</th>';
							$html .='<th class="mega_invoice_th_tr_td" style="padding: 5px;font-size: 13px;">مبلغ تک</th>';
							$html .='<th class="mega_invoice_th_tr_td" style="padding: 5px;font-size: 13px;">جمع</th>';
						$html .='</tr>';
					$html .='</thead>';
					$html .='<tbody class="mega_invoice_tbody">';
					$i = 1;
					foreach ( $order->get_items() as $item_id => $item  ) {
						$bm = json_decode($item);
						
						$product = wc_get_product($bm->product_id);
						$product_id = $bm->product_id;
						$html .='<tr class="mega_invoice_tb_tr">';
							$html .='<td class="mega_invoice_tb_tr_td" style="font-size: 13px;padding: 2px;">'.$i.'</td>';
							$html .='<td class="mega_invoice_tb_tr_td" style="font-size: 13px;padding: 2px;">'.$product->get_name().'</td>';
							$html .='<td class="mega_invoice_tb_tr_td mtn_quantity" style="font-size: 13px;padding: 2px;"><div><input type="number" name="mtn_qty" min="1" max="5" value="'.$bm->quantity.'" style="border:none;margin:none"></div></td>';
							
							$ptemp = 0 ;
							

							$sood = (  ($product->get_price())*($palan_precent)  )/100;

							$mahsool =$product->get_price() ;

							$ptemp = $sood + $mahsool;
							$html .='<td class="mega_invoice_tb_tr_td mtn_price" sood="'.$sood.'" cp="'.$product->get_price().'" price="'.$ptemp.'" pp="'.$palan_precent.'" style="font-size: 13px;padding: 2px;">'.number_format($ptemp).'</td>';

							$ptemp = 0;


							$sood =(($bm->total)*($palan_precent))/100; 
							$mahsool = $bm->total;
							$ptemp = $sood  + $mahsool;
							$html .='<td class="mega_invoice_tb_tr_td mtn_total" total="'.$ptemp.'" style="font-size: 13px;padding: 2px;">'.number_format($ptemp).'</td>';
						$html .='</tr>';
						$i++;
					}
					$html .='</tbody>';
					
					$html .='<table class="mega_invoice_tfooter">';
						$html .='<tbody>';
							$html .='<tr class="mega_invoice_tf_tr">';
								$html .='<th class="mega_invoice_tf_tr_td"><span>جمع به ریال </span></th>';
								$ptemp = 0;
								$pprice = get_post_meta($bm->product_id , '_price' , true);
								

								$sood =(($order->get_total()) * ($palan_precent) ) / 100; 
								$mahsool = $order->get_total();
								$ptemp = $sood  + $mahsool;
								$html .='<td class="mega_invoice_tf_tr_td all_total_price" all_total_price="'.$ptemp.'"><strong>'.number_format($ptemp).'<strong></td>';
							$html .='</tr>';
						$html .='</tbody>';
					$html .='</table>';

				$html .='</table>';
				$html .='<div class="invoice_footer d-flex flex-wrap">';
					$html .='<div class="col-12">';
						$html .='<p>پیش فاکتور صادر شده صرفا جهت ارائه به بانک بوده و فاقد هر گونه ارزش دیگر است . </p>';
						$html .='<p><strong>توجه : </strong><span>مدت اعتبار پیش فاکتور از تاریخ صدور به مدت 5 روز کاری می باشد . </span></p>';
						$html .='<p><strong>توجه : </strong><span>تحویل کالا مشروط به ارائه پیش فاکتور تأیید شده بانک به نمایندگی صادر کننده پیش فاکتور می باشد .</span></p>';
					$html .='</div>';
					$html .='<div class="col-6">مهر و امضاء نمایندگی فروش </div>';
					$html .='<div class="col-6">امضاء خریدار</div>';
				$html .='</div>';
			$html .='</div>';
			$html .='<div class="mega_print_invoice">';
				$html .='<button onclick="print_area_of(\'printarea\')">چاپ فاکتور</a>';
			$html .='</div>';
			echo $html;

			
		}
	}
}