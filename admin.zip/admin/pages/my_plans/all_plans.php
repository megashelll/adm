<?php 

global $wpdb ;

$sql = "SELECT * FROM `edu_posts` WHERE `post_type` LIKE 'leasing_plans' ORDER BY `ID` DESC";
$plans = $wpdb -> get_results($sql);

$html = '<table id="all_branch_list">';
	$html .= '<thead class="abl_header">';
		$html .= '<tr class="abl_h_row">';
			$html .= '<th class="abl_h_row_number">ردیف</th>';
			$html .= '<th class="abl_h_name">عنوان</th>';
			$html .= '<th class="abl_h_remove">ویرایش</th>';
			$html .= '<th class="abl_h_remove">وضعیت</th>';
		$html .= '</tr>';
	$html .= '</thead>';
	$i = 1;
	$html .= '<tbody>';
	foreach($plans as $b){
		
		$html .= '<tr>';
			$html .= '<td class="abl_b_row_number">'.$i.'</td>';$i++;
			$html .= '<td class="abl_b_row_number">'.$b->post_title.'</td>';
			$html .= '<td class="abl_b_row_number">'.$b->post_status.'</td>';
			$html .= '<td class="abl_b_row_number"><button onclick="edit_plan(\''.$b->ID.'\')">ویرایش</button></td>';
		$html .= '</tr>';
	}
	$html .= '</tbody>';
$html .= '</table>';

echo $html;