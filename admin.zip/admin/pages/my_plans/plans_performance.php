<?php 
global $wpdb;
global $woocommerce;
$table_name = $wpdb->prefix . 'branch_customers';
$sql  = "SELECT * FROM '{$table_name}' as a WHERE a.plan_id = 45136 ORDER BY a.order_id DESC" ;
$sql ="SELECT * FROM `edu_branch_customers` AS a WHERE a.plan_id = 45136 ORDER BY a.order_id DESC" ;



$sql = "SELECT 
			r.plan_id,
			COUNT(*) AS order_count,
			SUM(r.total_factor) AS total_amount,
			SUM(CASE WHEN p.post_status = 'wc-pending' THEN r.total_factor ELSE 0 END) AS pending_total,
			COUNT(CASE WHEN p.post_status = 'wc-pending' THEN 1 ELSE NULL END) AS pending_count,
			SUM(CASE WHEN p.post_status = 'wc-processing' THEN r.total_factor ELSE 0 END) AS processing_total,
			COUNT(CASE WHEN p.post_status = 'wc-processing' THEN 1 ELSE NULL END) AS processing_count,
			SUM(CASE WHEN p.post_status = 'wc-completed' THEN r.total_factor ELSE 0 END) AS completed_total,
			COUNT(CASE WHEN p.post_status = 'wc-completed' THEN 1 ELSE NULL END) AS completed_count,
			SUM(CASE WHEN p.post_status = 'wc-cancelled' THEN r.total_factor ELSE 0 END) AS cancelled_total,
			COUNT(CASE WHEN p.post_status = 'wc-cancelled' THEN 1 ELSE NULL END) AS cancelled_count,
			SUM(CASE WHEN p.post_status = 'wc-ersal_shode' THEN r.total_factor ELSE 0 END) AS ersal_total,
			COUNT(CASE WHEN p.post_status = 'wc-ersal_shode' THEN 1 ELSE NULL END) AS ersal_count
		FROM 
			edu_year_report r
		JOIN 
			edu_posts p ON r.order_id = p.ID
		WHERE 
			p.post_type = 'shop_order' -- یا هر post_type مرتبط با سفارشات شما
		GROUP BY 
			r.plan_id;";
$results = $wpdb ->get_results ($sql);





$html .='<ul class="mega_lisht_plan">';


	$html .='<table>';

		$html .='<thead>';
			$html .='<tr>';
				$html .='<th>ردیف</th>';
				$html .='<th>نام طرح</th>';

				$html .='<th>جمع کل مبلغ</th>';
				$html .='<th>تعداد کل</th>';

				$html .='<th>جمع پیش فاکتور</th>';
				$html .='<th>تعداد پیش فاکتور</th>';

				$html .='<th>جمع در حال بررسی</th>';
				$html .='<th>تعداد درحال بررسی</th>';

				$html .='<th>جمع تکمیل شده</th>';
				$html .='<th>تعداد تکمیل شده</th>';

				$html .='<th>جمع لغو شده</th>';
				$html .='<th>تعداد لغو شده</th>';

				$html .='<th>جمع ارسال شده</th>';
				$html .='<th>تعداد ارسال شده</th>';
				
			$html .='</tr>';
		$html .='</thead>';
		
		$i = 1 ; 
		$total_sum = 0;
		$html .='<tbody>';
		foreach($results as $plans){
			$the_plan = get_post($plans->plan_id);
			if (true){
				$html .= '<tr>';
					$html .= '<td class="m_sig_1">';
						$html .= $i ; $i++;
					$html .= '</td>';
					$html .= '<td class="m_sig_1">';
						$html .= $the_plan->post_title;
					$html .= '</td>';

					$html .= '<td class="m_sig_1">';
						$html .= number_format($plans->total_amount);
						$total_sum = $total_sum + intval($plans->total_amount);
					$html .= '</td>';
					$html .= '<td class="m_sig_1">';
						$html .= $plans->order_count;
					$html .= '</td>';

					$html .= '<td class="m_sig_1">';
						$html .= number_format($plans->pending_total);
					$html .= '</td>';
					$html .= '<td class="m_sig_1">';
						$html .= $plans->pending_count;
					$html .= '</td>';
					
					$html .= '<td class="m_sig_1">';
						$html .= number_format($plans->processing_total);
					$html .= '</td>';
					$html .= '<td class="m_sig_1">';
						$html .= $plans->processing_count;
					$html .= '</td>';
					
					$html .= '<td class="m_sig_1">';
						$html .= number_format($plans->completed_total);
					$html .= '</td>';
					$html .= '<td class="m_sig_1">';
						$html .= $plans->completed_count;
					$html .= '</td>';

					
					$html .= '<td class="m_sig_1">';
						$html .= number_format($plans->cancelled_total);
					$html .= '</td>';
					$html .= '<td class="m_sig_1">';
						$html .= $plans->cancelled_count;
					$html .= '</td>';

					
					$html .= '<td class="m_sig_1">';
						$html .=number_format($plans->ersal_total);
					$html .= '</td>';
					$html .= '<td class="m_sig_1">';
						$html .= $plans->ersal_count;
					$html .= '</td>';
				$html .= '<tr>';	
			}
			
		}
		$html .='</tbody>';
	$html .='</table>';


$html .='</ul>';



$html .='<p>جمع کل  : '.number_format($total_sum).' ریال</p>';
echo $html ;