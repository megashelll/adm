<?php 
global $wpdb;
$t1= $wpdb->prefix . 'terms';
$t2= $wpdb->prefix . 'term_taxonomy';
$sql = "SELECT B.term_id , B.name FROM `edu_term_taxonomy`as A INNER JOIN `edu_terms` AS B on A.term_id = B.term_id WHERE A.parent='0' and A.taxonomy='state_city';";
$states  = $wpdb -> get_results($sql);

?>
<div class="mega_admin_create_user container">
    <div class="mbcu_header_title">
        <h1>
            <span>افزودن نمایندگی ( عاملیت فروش )</span>
            <span>[ <span><?php echo get_bloginfo('name'); ?></span> ]</span>
        </h1>
    </div>

	
    <div class="mbcu_inner d-flex flex-wrap">
		<div class="macu_item col-lg-6 col-md-12">
			<label for="fist_name"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>نام</label>
			<input type="text" name="branch_first_name" required>
		</div>
		<div class="macu_item col-lg-6 col-md-12">
			<label for="last_name"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>نام خانوادگی </label>
			<input type="text" name="branch_last_name" required>
		</div>
		<div class="macu_item col-12">
			<label for="user_id_number"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>کد ملی نماینده</label>
			<input type="text" name="branch_id_number" required size="10">
		</div>
		<hr>
		
		<div class="macu_item col-lg-6 col-md-12 states">
			<label for="user_state"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>استان</label>
			<select name="branch_state" required onchange='changes_the_state_cities(jQuery(this).val());'>
				<option disabled>استان مورد نظر خود را انتخاب کنید</option>
				<?php foreach($states as $stat):?>	
					<option value="<?php echo $stat->term_id; ?>"><?php echo $stat->name; ?></option>
				<?php endforeach; ?>
			</select>
		</div>

		<div class="macu_item col-lg-6 col-md-12 city">
			<label for="user_city"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>شهر</label>
			<select name="branch_city" required >
				<option disabled>شهر مورد نظر خود را انتخاب کنید</option>
			</select>
		</div>
		
		<div class="macu_item col-12">
			<label for="user_address"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>آدرس فروشگاه</label>
			<input type="text" name="branch__address"  required>
		</div>
		
		<div class="macu_item col-12">
			<label for="zip_postal_code"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>کدپستی فروشگاه</label>
			<input type="text" name="branch_zip_postal_code" required size="10">
		</div>
		<hr>
		<div class="macu_item col-lg-6 col-md-12">
			<label for="user_phone"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>تلفن ثابت فروشگاه </label>
			<input type="text" name="branch_phone" required>
		</div>
		<div class="macu_item col-lg-6 col-md-12">
			<label for="user_mobile"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>تلفن همراه نماینده</label>
			<input type="text" name="branch_mobile" required size="11">
		</div>

		<div class="macu_item col-12">
			<label for="user_mobile"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>کد قرارداد</label>
			<input type="text" name="branch_contract_serial" required>
		</div>

		<div class="macu_item col-12">
			<label for="user_mobile"><span><abbr title="آیتم الزامی ـ حتما باید این فیلد را با مقدار صحیح پر کنید">*</abbr></span>کد شش رقمی نمایندگی</label>
			<input type="text" name="branch_serial_number" required>
		</div>

		<hr>
		<div class="mbcu_submit col-12">
			<button onclick="add_new_branch_ajax('<?php echo get_current_user_id();?>')" class="register_button">ثبت نام نمایندگی</button>
		</div>

    </div>
</div>