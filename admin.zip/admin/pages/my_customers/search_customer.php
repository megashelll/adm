<?php 
	global $wpdb;

	$table = $wpdb -> prefix . 'branch_customers';
	$table_metas = $wpdb -> prefix . 'postmeta';
	$current_user_id = get_current_user_id() ; 
	$temp_url = get_template_directory_uri();
	$limit = 20 ; 
	$page = 0;
?>

<style>
	.mounted_box.off{
		display:none;
	}
	.mega_igp_flex {
		width: 100%;
		flex: 0 0 100%;
	}
	.mega_igp_input {
		flex-grow: 1;
	}
	.mega_igp_comment {
		text-align: center;
		font-size: 12px;
		margin-bottom: 10px;
		border-bottom: 1px solid gainsboro;
		padding: 0px 10px 20px;
	}
	.ml-2 {
		margin-left: 10px;
	}
	.bangle_form_icon img{
		opacity:0.5;
		filter: blur(0.5px)
	}
	.bangle_form_icon:hover img {
		filter: blur(0px)invert(1);
		opacity:1;
	}
	.mega_list_of_orders,.mloo_master {
		z-index: 1;
	}
	.mega_igp {
		z-index: 1;
	}

	.mounted_box.active_popup {
		z-index: 3;
		display: flex;
		justify-content: center;
		align-items: center;
	}
</style>
<?php 
	

	$pagination ='<div class="mega_leas_pagination d-flex flex-wrap " current="{$currnt_page}" all="{$limit}">';
		
	$pagination .='</div>';
	
	$search ='<div class="mega_igp">';
		$search .='<div class="mega_igp_flex d-flex flex-wrap">';
			$search .='<div class="mega_igp_button">';
				$search .='<button class="btn btn-success" onclick="search_customer_by_name(\'mega_list_of_orders\')"><span>[جستجو]</span></button>';
			$search .='</div>';
			$search .='<div class="mega_igp_input">';
				$search .='<input type="text" name="search_user_by_name" class="form-control" >';
			$search .='</div>';
		$search .='</div>';
		$search .='<div class="mega_igp_comment">نام مشتری</div>';
	$search .='</div>';
	

	if (current_user_can('administrator')){
		$user_sea = 'all';
	}else{
		$user_sea = 'rstricted';
	}

	$i = 0 ; 
	$ajox = array();
	$json = '';
	



	echo '<div class="mounted_box position-fixed off"></div>';
	echo $search; 

	$h ='<div class="mega_ajax_holder" cu_id ="'.$current_user_id.'"></div>';
	$h .='<div class="mloo_master">';
		$h .='<div class="mbcu_header_title">';
			$h .='<h1>';
				$h .='<span>آخرین فاکتور ها<span style="font-size:10px; color:red;">   ۲۰۰ مورد   </span></span>';
				$h .='<span>[ <span>'.get_bloginfo('name').'</span> ]</span>';
			$h .='</h1>';
		$h .='</div>';
		$h .='<div class="mbcu_inner d-flex flex-wrap">';
			$h .='<table class="tabel_of_admin display">';
				$h .='<thead>';
					$h .='<tr>';
						$h .='<th>ردیف</th>';
						$h .='<th>نام</th>';
						$h .='<th>شناسه</th>';
						$h .='<th>کد ملی</th>';
						$h .='<th>همراه</th>';
						$h .='<th>گزینه ها</th>';
					$h .='</tr>';
				$h .='</thead>';
				
				echo $h ;
				
				$h = '';
				$h .='<tbody class="mega_list_of_orders">';
				
				foreach($invoices as $key => $value){

					$customer = get_user_by('ID' , $value->customer_id);
					$order_id = $value -> order_id;
					$customer_full_name = get_user_meta($value->customer_id , 'first_name' , true) . ' ' . get_user_meta($value->customer_id , 'last_name' , true);
					$branch_zone = get_user_meta($value->branch_id , 'branch_zone' , true);
					$branch_full_name = get_user_meta($value->branch_id , 'first_name' , true) . ' ' . get_user_meta($value->branch_id , 'last_name' , true);
					$order = wc_get_order( $value -> order_id );
					
					if ($user_sea == 'all'){	
						if (!empty($customer) & !empty($order) & $branch_full_name != ''){	
							$h .= '<tr order_id="'.$order_id .'" branch_id="'.$value->branch_id.'">';
								$h .= '<td>'.$order_id . '<br>' . $customer_full_name.'</td>';
								$h .= '<td>'.$branch_full_name.'</td>';
								$h .= '<td>'.$order->get_total().'</td>';
								$h .= '<td></td>';
							$h .= '</tr>';
							$i++ ;
						}
					}else{
						$user_master_id = get_user_meta( $value->ID , 'Create_by_masetr'  , true) ;
						if ($user_master_id == get_current_user_id()){	
						}	
					}	

				}
				$h .='</tbody>';
			$h .='</table>';
			$h .= $pagination; 
		
		$h .='</div>';
	$h .='</div>';
	echo $h ;