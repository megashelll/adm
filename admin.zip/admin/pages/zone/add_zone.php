<?php 
	global $wpdb ; 
	$data = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/state.json'));
	$city_data = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/city.json'));
	$sql = "SELECT user_id FROM `edu_usermeta` WHERE `meta_key` LIKE 'edu_capabilities' AND `meta_value` LIKE '%leasing%'";
	$leasings = $wpdb->get_results($sql);




	$leasing = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/city.json'));

	$h = '';
?>

<div class="add_new_zone">
	<label>نام منطقه جدید</label>
	<input type="text" name="zone_name" placeholder="نام منطقه">
	<label>استان منطقه جدید را انتخاب کنید</label>
	<select class="sel2" name="zone_states" placeholder="انتخاب استان"  multiple="multiple">
		<?php 
			foreach($data as $prov){
				echo '<option value="'.$prov->id.'">'.$prov->name.'</option>';
			}
		?>
	</select>
	
	<label>کارمند فعال در منطقه را انتخاب کنید</label>
	<select class="sel2" name="leasing_employee" placeholder="انتخاب کارمند" multiple="multiple">
		<?php 
			foreach($leasings as $ls){
				$user = get_user_by('ID' , $ls->user_id);
				if ($user){
					echo '<option value="'.$user->ID.'">'.$user->data->display_name.'</option>';		
				}
			} 
		?>
	</select>

	<button onclick="add_new_zone()">افزودن منطقه جدید</button>
</div>
<div class="add_new_zone_results">
</div>


<?php 
	// $new_prov = array();

	// $i=0;
	// foreach($data as $province){
		
	// 	$my_city = array();
	// 	foreach($city_data as $city){
	// 		if ($city->province_id == $province->id){
	// 			$my_city[] = [
	// 				'id' => $city->id,
	// 				'name' => $city->name,
	// 				'province' => $city->province_id
	// 			];
	// 		}
	// 	}
	// 	$new_prov[$i]=[
	// 		'id' => $province->id,
	// 		'name' => $province->name,
	// 		'city'	=> $my_city
	// 	];

	// 	$i++;
	// }
	// $finprov = json_encode($new_prov);
	// print_r($finprov);
	// update_option('city_state' , $finprov);

