<?php 
// اضافه کردن CDN بوت‌استرپ آیکون‌ها
echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">';

// اسکریپت تولتیپ‌ها
echo "<script>
    document.addEventListener('DOMContentLoaded', function() {
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle=\"tooltip\"]');
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    });
</script>";

global $wpdb;
$states = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/state.json'));
$sql = "SELECT * FROM `edu_posts` WHERE `post_type` LIKE 'zone_area' ORDER BY `ID` DESC";
$zones = $wpdb->get_results($sql);

$all = get_option(city_state);
$h = '';
$h .= '<div class="container-fluid py-4">';
    // Add Zone Button
    $h .= '<div class="row mb-4">';
        $h .= '<div class="col-12">';
            $h .= '<a class="btn btn-primary d-inline-flex align-items-center" 
                      href="'. get_site_url().'/my-account/?admin=add_zone" 
                      data-bs-toggle="tooltip" 
                      data-bs-placement="top" 
                      data-bs-title="افزودن منطقه جدید به سیستم">
                      <i class="bi bi-plus-circle me-2"></i>
                      افزودن منطقه جدید
                  </a>';
        $h .= '</div>';
    $h .= '</div>';
    
    // Main Card
    $h .= '<div class="card shadow-sm">';
        $h .= '<div class="card-header bg-light py-3">';
            $h .= '<div class="row align-items-center">';
                $h .= '<div class="col">';
                    $h .= '<h5 class="mb-0"><i class="bi bi-geo-alt me-2"></i>مدیریت مناطق</h5>';
                    $h .= '<small class="text-muted">'.get_bloginfo('name').'</small>';
                $h .= '</div>';
            $h .= '</div>';
        $h .= '</div>';
        
        $h .= '<div class="card-body">';
            $h .= '<div class="table-responsive">';
                $h .= '<table class="table table-hover table-striped align-middle" id="zonesTable">';
                    $h .= '<thead class="table-light">';
                        $h .= '<tr>';
                            $h .= '<th scope="col" width="70">ردیف</th>';
                            $h .= '<th scope="col" width="80">شناسه</th>';
                            $h .= '<th scope="col">نام منطقه</th>';
                            $h .= '<th scope="col">مدیر منطقه</th>';
                            $h .= '<th scope="col">کارشناسان</th>';
                            $h .= '<th scope="col">استان‌ها</th>';
                            $h .= '<th scope="col" width="140">عملیات</th>';
                        $h .= '</tr>';
                    $h .= '</thead>';
                    
                    echo $h;
                    
                    $h = '';
                    $h .= '<tbody>';
                    $i = 1;
                    foreach($zones as $area) {
                        $leasing_employee = get_post_meta($area->ID, 'leasing_employee', true);
                        $zone_states = get_post_meta($area->ID, 'zone_states', true);
                        $zone_master = get_post_meta($area->ID, 'zone_master', true);
                        $master_data = get_user_by('ID', $zone_master['0']);

                        $h .= '<tr>';
                            $h .= '<td>'. $i .'</td>';
                            $h .= '<td>'. $area->ID .'</td>';
                            $h .= '<td>'. $area->post_title .'</td>';
                            $h .= '<td>';
                                $h .= '<div class="d-flex align-items-center">';
                                    $h .= '<div class="bg-light rounded-circle p-2 me-2">';
                                        $h .= '<i class="bi bi-person"></i>';
                                    $h .= '</div>';
                                    $h .= '<span>'. $master_data->data->display_name .'</span>';
                                $h .= '</div>';
                            $h .= '</td>';
                            
                            $h .= '<td>';
                                $h .= '<div class="d-flex flex-wrap gap-1">';
                                foreach($leasing_employee as $leasing) {
                                    $user = get_user_by('ID', $leasing);
                                    $h .= '<span class="badge bg-light text-dark">';
                                        $h .= '<i class="bi bi-person-badge me-1"></i>';
                                        $h .= $user->data->display_name;
                                    $h .= '</span>';
                                }
                                $h .= '</div>';
                            $h .= '</td>';

                            $h .= '<td>';
                                $h .= '<div class="d-flex flex-wrap gap-1">';
                                foreach($zone_states as $zone) {
                                    foreach($states as $state) {
                                        if ($state->id == $zone) {
                                            $h .= '<span class="badge bg-info">';
                                                $h .= '<i class="bi bi-geo me-1"></i>';
                                                $h .= $state->name;
                                            $h .= '</span>';
                                        }
                                    }
                                }
                                $h .= '</div>';
                            $h .= '</td>';
                            
                            $h .= '<td>';
                                $h .= '<div class="btn-group" role="group">';
                                    // دکمه افزودن کارشناس
                                    $h .= '<button type="button" 
                                            class="btn btn-sm btn-outline-primary" 
                                            data-bs-toggle="tooltip" 
                                            data-bs-placement="top" 
                                            data-bs-title="افزودن کارشناس جدید به منطقه" 
                                            onclick="load_modal_data(\'add_new_employee_to_zone\', \''. $area->ID .'\')">';
                                        $h .= '<i class="bi bi-person-plus"></i>';
                                    $h .= '</button>';
                                    
                                    // دکمه ویرایش
                                    $h .= '<a href="'. get_site_url() .'/my-account/?admin=edit_zone&zone='. $area->ID .'" 
                                            class="btn btn-sm btn-outline-secondary"
                                            data-bs-toggle="tooltip" 
                                            data-bs-placement="top" 
                                            data-bs-title="ویرایش اطلاعات منطقه">';
                                        $h .= '<i class="bi bi-pencil-square"></i>';
                                    $h .= '</a>';
                                    
                                    // دکمه حذف
                                    $h .= '<button 
                                            class="btn btn-sm btn-outline-danger"
                                            data-bs-toggle="tooltip" 
                                            data-bs-placement="top" 
                                            data-bs-title="حذف منطقه" 
                                            onclick="remove_zone_by_master(\''. $area->ID .'\')">';
                                        $h .= '<i class="bi bi-trash"></i>';
                                    $h .= '</button>';
                                $h .= '</div>';
                            $h .= '</td>';
                        $h .= '</tr>';
                        $i++;
                    }
                    $h .= '</tbody>';
                $h .= '</table>';
            $h .= '</div>';
        $h .= '</div>';
    $h .= '</div>';
$h .= '</div>';

// Modal
$modal = '
<div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal_title">
                    <i class="bi bi-person-plus me-2"></i>
                    افزودن کارشناس جدید
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal_body">
                <!-- Modal content will be loaded dynamically -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="bi bi-x-lg me-1"></i>
                    انصراف
                </button>
                <button type="button" class="btn btn-primary" id="save_the_dialog">
                    <i class="bi bi-check-lg me-1"></i>
                    ذخیره تغییرات
                </button>
            </div>
        </div>
    </div>
</div>
';

echo $modal;
echo $h;
?>

<style>
.badge {
    font-size: 0.8rem;
    font-weight: normal;
}

.btn-group .btn {
    padding: 0.25rem 0.5rem;
}

.table > :not(caption) > * > * {
    padding: 1rem 0.75rem;
}

.table th {
    font-weight: 500;
}

.card {
    border: none;
}

.modal-dialog-centered {
    display: flex;
    align-items: center;
    min-height: calc(100% - 1rem);
}

/* تنظیمات تولتیپ */
.tooltip {
    font-family: inherit !important;
    font-size: 0.75rem;
    opacity: 1 !important;
}

.tooltip-inner {
    background-color: #343a40;
    padding: 0.5rem 0.75rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.bs-tooltip-top .tooltip-arrow::before {
    border-top-color: #343a40;
}

@media (max-width: 768px) {
    .table {
        font-size: 0.875rem;
    }
    
    .badge {
        font-size: 0.75rem;
    }
}
</style>