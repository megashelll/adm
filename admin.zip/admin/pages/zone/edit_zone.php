

<?php 
global $wpdb; 
$data = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/state.json'));
$city_data = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/city.json'));
$sql = "SELECT user_id FROM `edu_usermeta` WHERE `meta_key` LIKE 'edu_capabilities' AND `meta_value` LIKE '%leasing%'";
$leasings = $wpdb->get_results($sql);

$leasing = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/city.json'));

$h = '';
echo '<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>';
if (isset($_GET['zone'])) {
    $zone_id = $_GET['zone'];
    $zone = get_post($_GET['zone']);

    if ($zone) {
        // Container Start
        $h = '<div class="container-fluid py-4">';
            // Main Card
            $h .= '<div class="card shadow-sm">';
                // Card Header
                $h .= '<div class="card-header bg-light py-3">';
                    $h .= '<div class="d-flex align-items-center">';
                        $h .= '<i class="bi bi-pencil-square me-2"></i>';
                        $h .= '<h5 class="mb-0">ویرایش منطقه</h5>';
                    $h .= '</div>';
                $h .= '</div>';

                // Card Body
                $h .= '<div class="card-body">';
                    $h .= '<form class="row g-4">';
                        // Zone Name
                        $h .= '<div class="col-12">';
                            $h .= '<div class="form-floating">';
                                $h .= '<input type="text" 
                                              class="form-control" 
                                              id="zoneName" 
                                              name="zone_name" 
                                              placeholder="نام منطقه" 
                                              value="'.$zone->post_title.'">';
                                $h .= '<label for="zoneName">نام منطقه</label>';
                            $h .= '</div>';
                        $h .= '</div>';

                        // States Select
                        $h .= '<div class="col-md-6">';
                            $h .= '<label class="form-label">استان‌های منطقه</label>';
                            $h .= '<select class="form-select sel2" 
                                          name="zone_states" 
                                          multiple 
                                          data-bs-toggle="tooltip" 
                                          data-bs-placement="top" 
                                          data-bs-title="می‌توانید چند استان را انتخاب کنید">';
                                $st = get_post_meta($zone_id, 'zone_states', true);
                                foreach($data as $prov) {
                                    $selected = '';
                                    if(is_array($st)) {
                                        foreach($st as $ts) {
                                            if ($ts == $prov->id) {
                                                $selected = 'selected';
                                                break;
                                            }
                                        }
                                    }
                                    $h .= '<option value="'.$prov->id.'" '.$selected.'>'.$prov->name.'</option>';
                                }
                            $h .= '</select>';
                        $h .= '</div>';

                        // Employees Select
                        $h .= '<div class="col-md-6">';
                            $h .= '<label class="form-label">کارمندان فعال در منطقه</label>';
                            $h .= '<select class="form-select sel2" 
                                          name="leasing_employee" 
                                          multiple 
                                          data-bs-toggle="tooltip" 
                                          data-bs-placement="top" 
                                          data-bs-title="می‌توانید چند کارمند را انتخاب کنید">';
                                foreach($leasings as $ls) {
                                    $us = get_post_meta($zone_id, 'leasing_employee', true);
                                    $user = get_user_by('ID', $ls->user_id);
                                    
                                    if ($user) {
                                        $selected = '';
                                        if(is_array($us)) {
                                            foreach($us as $ts) {
                                                if ($ts == $user->id) {
                                                    $selected = 'selected';
                                                    break;
                                                }
                                            }
                                        }
                                        $h .= '<option value="'.$user->ID.'" '.$selected.'>'.$user->data->display_name.'</option>';
                                    }
                                }
                            $h .= '</select>';
                        $h .= '</div>';

                        // Save Button
                        $h .= '<div class="col-12 text-end">';
                            $h .= '<button type="button" 
                                          class="btn btn-primary" 
                                          onclick="save_zone(\''.$zone_id.'\')">';
                                $h .= '<i class="bi bi-check2-circle me-2"></i>';
                                $h .= 'ذخیره تغییرات';
                            $h .= '</button>';
                        $h .= '</div>';
                    $h .= '</form>';

                    // Results Container
                    $h .= '<div class="save_zone_results mt-4"></div>';
                $h .= '</div>';
            $h .= '</div>';
        $h .= '</div>';
    }
}

echo $h;
?>

<style>
/* Custom Select2 Styles */
.select2-container--bootstrap-5 .select2-selection {
    border: 1px solid #dee2e6;
    padding: 0.375rem 0.75rem;
    height: auto;
    min-height: 40px;
}

.select2-container--bootstrap-5 .select2-selection--multiple .select2-selection__rendered {
    display: flex;
    flex-wrap: wrap;
    gap: 0.25rem;
    padding: 0;
}

.select2-container--bootstrap-5 .select2-selection--multiple .select2-selection__choice {
    background-color: #e9ecef;
    border: none;
    border-radius: 4px;
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
}

.select2-container--bootstrap-5 .select2-search__field {
    margin: 0;
}

.form-floating > .form-control {
    height: calc(3.5rem + 2px);
    line-height: 1.25;
}

.form-floating > label {
    padding: 1rem 0.75rem;
}

/* Tooltip Styles */
.tooltip {
    font-family: inherit !important;
    font-size: 0.75rem;
}

.tooltip-inner {
    background-color: #343a40;
    padding: 0.5rem 0.75rem;
}

/* Card Styles */
.card {
    border: none;
}

.card-header {
    background-color: rgb(248, 249, 250);
}
</style>

<script>
// Initialize Select2 with Bootstrap 5 theme
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Select2
    jQuery('.sel2').select2({
        theme: 'bootstrap-5',
        width: '100%',
        placeholder: 'انتخاب کنید...',
        language: {
            noResults: function() {
                return "موردی یافت نشد";
            }
        }
    });

    // Initialize Tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>