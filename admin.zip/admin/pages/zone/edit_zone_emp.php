<?php 
	global $wpdb ; 
	$data = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/state.json'));
	$city_data = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/city.json'));
	

	
	$sql = "SELECT user_id FROM `edu_usermeta` WHERE `meta_key` LIKE 'edu_capabilities' AND `meta_value` LIKE '%leasing%'";
	$leasings = $wpdb->get_results($sql);

	
	

	$h = '';

	if (isset($_GET['zone'])){
			
		$zone_id = $_GET['zone'];
		$zone = get_post($_GET['zone']);
		$manager = get_post_meta($zone_id , 'leasing_employee' , true);

		$sql = "SELECT user_id FROM `edu_post_meta` WHERE `meta_key` LIKE 'zone_empo' AND `post_id` LIKE '{$zone_id}'";
		$zone_employees = $wpdb->get_results($sql);


		if ($manager){
			$man_count = 1;
			foreach($manager as $man ){
				if ($man_count == 1){
					$man_id = $man ; 
				}
			}

			if ($man_id){
				echo '<div class="col-12 bg-dark text-white">';
					echo '<div class="zone_name col-3">نام منطقه : '.get_the_title($zone_id).'</div>';
					echo '<div class="zone_manager col-3">مدیر منطقه : ' .'<span><strong>'.get_user_meta($man_id , 'first_name' , true) . ' ' .get_user_meta($man_id , 'last_name' , true) .'</strong></span></div>';
				echo '</div>';
			}else{
				echo 'مدیر منطقه : ' .'<span><strong>برای این منطقه مدیری انتخاب نشده است</strong></span>';
			}
			

			$h ='<div class="col-12 bg-light mt-2 mb-2 p-2">';
				$h .='<label>کارمند فعال در منطقه را انتخاب کنید</label>';
				$h .='<select class="sel2" name="leasing_employee[]" placeholder="انتخاب کارمند">';

					foreach ($leasings as $ls) {
						$user = get_user_by('ID', $ls->user_id); // گرفتن اطلاعات کاربر

						if ($user) {
							// بررسی اینکه آیا این کاربر در آرایه $zone_employees وجود دارد یا خیر
							if (in_array($user->ID, $zone_employees)) {
								$h .= '<option value="' . $user->ID . '" selected>' . $user->data->display_name . '</option>';
							} else {
								$h .= '<option value="' . $user->ID . '">' . $user->data->display_name . '</option>';
							}
						}
					}

				$h .= '</select>';
			$h .='</div>';
			$h .= '<div class="col-12 bg-light mt-2 mb-2 p-2">';
				$h .='<label>استان فعالیت کارمند</label>';
				$h .='<select class="sel2" name="zone_states" placeholder="انتخاب استان" multiple="multiple">';
					
					foreach($data as $prov){
						
						$h .='<option value="'.$prov->id.'">'.$prov->name.'</option>';
						
						
					}

				$h .='</select>';
				
				

				$h .='<button onclick="add_new_zone()">افزودن منطقه جدید</button>';
			$h .='</div>';
			$h .='<input type="hidden" name="zone_master_id" value="'.$zone_id.'">';
			echo $h ; 
		}

	}


?>







<?php 
	// $new_prov = array();

	// $i=0;
	// foreach($data as $province){
		
	// 	$my_city = array();
	// 	foreach($city_data as $city){
	// 		if ($city->province_id == $province->id){
	// 			$my_city[] = [
	// 				'id' => $city->id,
	// 				'name' => $city->name,
	// 				'province' => $city->province_id
	// 			];
	// 		}
	// 	}
	// 	$new_prov[$i]=[
	// 		'id' => $province->id,
	// 		'name' => $province->name,
	// 		'city'	=> $my_city
	// 	];

	// 	$i++;
	// }
	// $finprov = json_encode($new_prov);
	// print_r($finprov);
	// update_option('city_state' , $finprov);

