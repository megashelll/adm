<?php 
global $wpdb;
$user_tab = $wpdb->prefix . 'users';
$usermeta_tab = $wpdb->prefix . 'usermeta';
$current_user_id = get_current_user_id();

$sql = "SELECT * FROM `edu_users` AS a 
        INNER JOIN `edu_usermeta` AS b 
        ON a.ID = b.user_id 
        WHERE b.meta_key ='{$wpdb->prefix}capabilities' 
        AND b.meta_value LIKE '%leasing%';";
$user_list = $wpdb->get_results($sql);

$user_sea = current_user_can('administrator') ? 'all' : 'rstricted';

// Start Output
$html = '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
';

// Modal Container for AJAX responses

$html .= '<div class="mounted_box position-fixed off"></div>';
$html .= '<div class="mega_ajax_holder"></div>';

// Main Container
$html .= '<div class="container-fluid py-4">';

    // Main Card
    $html .= '<div class="card shadow-sm">';
        // Card Header
        $html .= '<div class="card-header bg-light py-3">';
            $html .= '<div class="d-flex align-items-center">';
                $html .= '<i class="bi bi-people-fill me-2 fs-4"></i>';
                $html .= '<div>';
                    $html .= '<h5 class="mb-0">مدیریت کارمندان</h5>';
                    $html .= '<small class="text-muted">'.get_bloginfo('name').'</small>';
                $html .= '</div>';
            $html .= '</div>';
        $html .= '</div>';

        // Card Body
        $html .= '<div class="card-body px-0">';
            $html .= '<div class="table-responsive">';
                $html .= '<table class="table table-hover align-middle mb-0">';
                    // Table Header
                    $html .= '<thead class="table-light">';
                        $html .= '<tr>';
                            $html .= '<th width="60">ردیف</th>';
                            $html .= '<th>نام</th>';
                            $html .= '<th>
                                        <div>همراه</div>
                                        <div class="border-top mt-2 pt-2">کد ملی</div>
                                    </th>';
                            $html .= '<th>مدیر</th>';
                            $html .= '<th width="100">تعداد مشتریان</th>';
                            $html .= '<th width="280">عملیات</th>';
                        $html .= '</tr>';
                    $html .= '</thead>';

                    // Table Body
                    $html .= '<tbody>';
                    $i = 1;
                    foreach($user_list as $value) {
                        if ($user_sea == 'all' || 
                            get_user_meta($value->ID, 'Create_by_masetr', true) == get_current_user_id()) {
                            
                            $sql_count = "SELECT DISTINCT COUNT(a.user_id) as addd 
                                        FROM `{$usermeta_tab}` AS a 
                                        INNER JOIN `{$user_tab}` AS b 
                                        on a.user_id = b.ID 
                                        WHERE a.meta_value = '{$value->ID}' 
                                        AND a.meta_key='branch_leasing_employee_id';";
                            $user_branches = $wpdb->get_results($sql_count);
                            
                            $html .= '<tr id="user_id_'.$value->ID.'">';
                                // Row Number
                                $html .= '<td class="text-muted">'.$i.'</td>';
                                
                                // Full Name
                                $full_name = get_user_meta($value->ID, 'first_name', true) . ' ' . 
                                           get_user_meta($value->ID, 'last_name', true);
                                $html .= '<td>
                                    <div class="d-flex align-items-center">
                                        <div class="bg-light rounded-circle p-2 me-2">
                                            <i class="bi bi-person-fill"></i>
                                        </div>
                                        <span>'.$full_name.'</span>
                                    </div>
                                </td>';
                                
                                // Mobile & National ID
                                $user_pid = get_user_meta($value->ID, 'user_public_id', true);
                                $html .= '<td>
                                    <div class="text-primary">'.$value->user_login.'</div>
                                    <div class="text-muted small border-top mt-2 pt-2">'.$user_pid.'</div>
                                </td>';
                                
                                // Master Info
                                $user_master_id = get_user_meta($value->ID, 'Create_by_masetr', true);
                                $user_master_name = get_user_meta($user_master_id, 'first_name', true) . ' ' . 
                                                  get_user_meta($user_master_id, 'last_name', true);
                                $html .= '<td>
                                    <span class="master_uid_'.$value->ID.'">'.$user_master_name.'</span>
                                </td>';
                                
                                // Customer Count
                                $html .= '<td>
                                    <span class="badge bg-info count_uid_'.$value->ID.'">
                                        '.$user_branches[0]->addd.'
                                    </span>
                                </td>';
                                
                                // Action Buttons
                                $html .= '<td>
                                    <div class="btn-group" role="group">
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-primary" 
                                                onclick="re_section_employee_leasing_by_admin(\''.$value->ID.'\')"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                title="تغییر مجموعه کارمند">
                                            <i class="bi bi-diagram-3-fill"></i>
                                        </button>

                                        <button type="button" 
                                                class="btn btn-sm btn-outline-info" 
                                                onclick="transfr_employee_leasing_customer_by_admin(\''.$value->ID.'\')"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                title="انتقال مشتریان به کارمند دیگر">
                                            <i class="bi bi-people-fill"></i>
                                        </button>

                                        <button type="button" 
                                                class="btn btn-sm btn-outline-success" 
                                                onclick="change_branches_employee(\''.$value->ID.'\')"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                title="مدیریت نماینده‌های کارمند">
                                            <i class="bi bi-shop-window"></i>
                                        </button>

                                        <button type="button" 
                                                class="btn btn-sm btn-outline-secondary" 
                                                onclick="edit_employee_leasing_by_admin(\''.$value->ID.'\')"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                title="ویرایش اطلاعات کارمند">
                                            <i class="bi bi-pencil-square"></i>
                                        </button>

                                        <button type="button" 
                                                class="btn btn-sm btn-outline-danger" 
                                                onclick="delet_employee_leasing_by_admin(\''.$value->ID.'\')"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                title="حذف کارمند">
                                            <i class="bi bi-trash3-fill"></i>
                                        </button>
                                    </div>
                                </td>';
                            $html .= '</tr>';
                            $i++;
                        }
                    }
                    $html .= '</tbody>';
                $html .= '</table>';
            $html .= '</div>';
        $html .= '</div>';
    $html .= '</div>';
$html .= '</div>';

// Add Styles
$html .= '<style>
    .table th {
        font-weight: 500;
        white-space: nowrap;
    }
    
    .btn-group .btn {
        padding: 0.4rem;
        margin: 0 2px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 32px;
        transition: all 0.2s ease-in-out;
    }

    .btn-group .btn:hover {
        transform: translateY(-2px);
    }
    
    .badge {
        font-weight: normal;
        font-size: 0.875rem;
        padding: 0.5em 0.75em;
    }
    
    .tooltip {
        font-family: inherit !important;
    }

    .tooltip-inner {
        background-color: #343a40;
        padding: 0.5rem 0.75rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    @media (max-width: 768px) {
        .btn-group {
            display: inline-flex;
            flex-wrap: nowrap;
        }
        
        .btn-group .btn {
            padding: 0.3rem;
            min-width: 28px;
        }
        
        .tooltip {
            font-size: 0.7rem;
        }
    }
</style>';


echo $html;
?>

<script>

</script>