<?php 
global $wpdb;

$html = '<div class="container-fluid py-4">';
    // Main Card
    $html .= '<div class="card shadow-sm">';
        // Card Header
        $html .= '<div class="card-header bg-light py-3">';
            $html .= '<div class="d-flex align-items-center">';
                $html .= '<i class="bi bi-person-plus-fill me-2 fs-4"></i>';
                $html .= '<div>';
                    $html .= '<h5 class="mb-0">ایجاد کاربر لیزینگ</h5>';
                    $html .= '<small class="text-muted">'.get_bloginfo('name').'</small>';
                $html .= '</div>';
            $html .= '</div>';
        $html .= '</div>';

        // Card Body
        $html .= '<div class="card-body">';
            $html .= '<form class="row g-4">';
                // First Name
                $html .= '<div class="col-md-6">';
                    $html .= '<div class="form-floating mb-1">';
                        $html .= '<input type="text" 
                                       class="form-control" 
                                       id="firstName" 
                                       name="first_name" 
                                       placeholder="نام" 
                                       value="'.$first_name.'" 
                                       required>';
                        $html .= '<label for="firstName">';
                            $html .= '<i class="bi bi-person me-1"></i>';
                            $html .= 'نام';
                            $html .= '<span class="text-danger">*</span>';
                        $html .= '</label>';
                    $html .= '</div>';
                    $html .= '<small class="text-muted">نام کوچک کارمند را وارد کنید</small>';
                $html .= '</div>';

                // Last Name
                $html .= '<div class="col-md-6">';
                    $html .= '<div class="form-floating mb-1">';
                        $html .= '<input type="text" 
                                       class="form-control" 
                                       id="lastName" 
                                       name="last_name" 
                                       placeholder="نام خانوادگی" 
                                       value="'.$last_name.'" 
                                       required>';
                        $html .= '<label for="lastName">';
                            $html .= '<i class="bi bi-person-vcard me-1"></i>';
                            $html .= 'نام خانوادگی';
                            $html .= '<span class="text-danger">*</span>';
                        $html .= '</label>';
                    $html .= '</div>';
                    $html .= '<small class="text-muted">نام خانوادگی کارمند را وارد کنید</small>';
                $html .= '</div>';

                // Mobile Number
                $html .= '<div class="col-md-6">';
                    $html .= '<div class="form-floating mb-1">';
                        $html .= '<input type="tel" 
                                       class="form-control" 
                                       id="userMobile" 
                                       name="user_mobile" 
                                       placeholder="تلفن همراه" 
                                       value="'.$user_mobile.'" 
                                       pattern="^09[0-9]{9}$"
                                       required>';
                        $html .= '<label for="userMobile">';
                            $html .= '<i class="bi bi-phone me-1"></i>';
                            $html .= 'تلفن همراه';
                            $html .= '<span class="text-danger">*</span>';
                        $html .= '</label>';
                    $html .= '</div>';
                    $html .= '<small class="text-muted">شماره موبایل را با فرمت 09XXXXXXXXX وارد کنید</small>';
                $html .= '</div>';

                // Submit Button Section
                $html .= '<div class="col-12 mt-4">';
                    $html .= '<hr class="my-4">';
                    $html .= '<div class="d-flex justify-content-end">';
                        $html .= '<button type="button" 
                                        class="btn btn-success d-inline-flex align-items-center" 
                                        onclick="add_new_employee(\'2\')"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="top"
                                        title="ثبت اطلاعات کارمند جدید">';
                            $html .= '<i class="bi bi-check2-circle me-2"></i>';
                            $html .= 'ثبت کارمند جدید';
                        $html .= '</button>';
                    $html .= '</div>';
                $html .= '</div>';
            $html .= '</form>';

            // Results Container
            $html .= '<div class="employee-form-results mt-3"></div>';
        $html .= '</div>';
    $html .= '</div>';
$html .= '</div>';

// Add Styles
$html .= '<style>
    /* Form Styles */
    .form-floating > .form-control {
        height: calc(3.5rem + 2px);
        line-height: 1.25;
    }

    .form-floating > label {
        padding: 1rem 0.75rem;
        color: #6c757d;
    }

    .form-control:focus {
        border-color: #86b7fe;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
    }

    /* Required Field Style */
    .text-danger {
        font-weight: bold;
        margin-right: 4px;
    }

    /* Card Style */
    .card {
        border: none;
        transition: all 0.3s ease;
    }

    .card:hover {
        box-shadow: 0 .5rem 1rem rgba(0,0,0,.15)!important;
    }

    /* Mobile Responsive */
    @media (max-width: 768px) {
        .form-floating > .form-control {
            height: calc(3.2rem + 2px);
        }
        
        .form-floating > label {
            padding: 0.8rem 0.75rem;
        }
    }
</style>';

// Add Scripts
$html .= '<script>
    // Initialize tooltips
    document.addEventListener("DOMContentLoaded", function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll(\'[data-bs-toggle="tooltip"]\'));
        var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
</script>';

echo $html;
?>