<?php 

	$path = preg_replace('/accounts.*$/','',__DIR__);
	include($path.'wp-load.php');

	$request_body = file_get_contents('php://input');
	$data = json_decode($request_body);

	$order = wc_get_order( $data -> order_id );
	?>
	
	
	<?php
	
	$h = '<div class="view_the_order_mega" order_id="'.$data -> order_id .'" branch_id="'.$value->branch_id.'">';

		$h .='<div class="popup_close_button position-absolute">';
			$h .='<button onclick="closetheareaof(\'mounted_box\')">X close</button>';
		$h .='</div>';


		$h .='<div class="order_view_chart">';
			foreach ( $order->get_items() as $item_id => $item ) {
				$item_type 		= $item->get_type();
				$product_id 	= $item->get_product_id();
				$product = wc_get_product( $product_id );
				if ($product){
					$product_type = $product->get_type();
					$i = 1 ;
					if ($product_type == 'simple'){
						$h .='<div class="mega_product_item d-flex felx-wrap product_item_'.$product_id.'"> ';

							$h .='<div class="mpi_row">';
								$h .=$i;
							$h .='</div>';

							$h .='<div class="mpi_name">';
								$h .=$product->get_name();;
							$h .='</div>';

							$h .='<div class="mpi_quantity" gty="'.$item->get_quantity().'">';
								$h .= '<div class="plus_qty_in_mpi">+</div>';
									$h .= '<span>'.$item->get_quantity().'</span>';
								$h .= '<div class="minus_qty_in_mpi">-</div>';
							$h .='</div>';

							$h .='<div class="mpi_subtotal" sub_total="'.$item->get_subtotal().'">';
								$h .=number_format($item->get_subtotal());
							$h .='</div>';

							$h .='<div class="mpi_total" total="'.$item->get_total().'">';
								$h .=number_format($item->get_total());
							$h .='</div>';
							
						$h .='</div>';
						$i++ ;
					}elseif($product_type == 'variation'){

					}
					
				}
				
				$variation_id 	= $item->get_variation_id();
				$product 		= $item->get_product(); // see link above to get $product info
				$product_name 	= $item->get_name();
				$quantity 		= $item->get_quantity();
				$subtotal 		= $item->get_subtotal();
				$total 			= $item->get_total();
				$tax 			= $item->get_subtotal_tax();
				$tax_class 		= $item->get_tax_class();
				$tax_status 	= $item->get_tax_status();
				$allmeta 		= $item->get_meta_data();
				$somemeta 		= $item->get_meta( '_whatever', true );
				$item_type 		= $item->get_type(); // e.g. "line_item", "fee"
			}
		$h .='</div>';
		
		$h .= '<div>';
			$h .='<button class="bangle_form_icon btn btn-success p-1 ml-2" onclick="save_order_changes(\''.$data -> order_id.'\' , \''.get_current_user_id().'\',\'mounted_box\')">';
				$h .='بروز رسانی';
			$h .='</button>';
			$h .='<button onclick="closetheareaof(\'mounted_box\')" class="bangle_form_icon btn btn-danger p-1 ml-2">انصراف</button>';
		$h .= '</div>';

	$h .= '</div>';
	echo $h ; 
			