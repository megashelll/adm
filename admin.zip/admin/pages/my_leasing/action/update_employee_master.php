<?php 

	$path = preg_replace('/accounts.*$/','',__DIR__);
include($path.'wp-load.php');

	$request_body = file_get_contents('php://input');
	$data = json_decode($request_body);

	if (update_user_meta($data->id ,'Create_by_masetr',$data->value)){
		echo 'yes';
	}else{
		echo 'no';
	}


?>
