<?php 

$path = preg_replace('/accounts.*$/','',__DIR__);
include($path.'wp-load.php');

$request_body = file_get_contents('php://input');
$data = json_decode($request_body);

global $wpdb ; 
$user_tab = $wpdb -> prefix .'users';
$usermeta_tab = $wpdb -> prefix . 'usermeta';
$current_user_id = get_current_user_id() ; 

$sql = "SELECT * FROM `{$user_tab}` AS a INNER JOIN `{$usermeta_tab}` AS b ON a.ID = b.user_id WHERE b.meta_key ='edu_capabilities' AND b.meta_value LIKE '%man_boss%';";
$user_bosses = $wpdb ->get_results($sql);

?>

<div class="mega_capsule_popup">
	<div class="mcp_inner">
		<h3 class="mb-4">مدیریت حوزه را انتخاب نمایید</h3>
		<select  name="employee_master">
		<?php 
			$Create_by_masetr = get_user_meta($data->id, 'Create_by_masetr' , true);
			
			foreach($user_bosses as $key => $user){
				if ($Create_by_masetr == $user -> ID){
					echo '<option  value="'.$user -> ID.'" selected>'.get_user_meta($user -> ID , 'first_name' , true) . ' ' .get_user_meta($user -> ID , 'last_name' , true).'</option>';
				}else{
					echo '<option  value="'.$user -> ID.'">'.get_user_meta($user -> ID , 'first_name' , true) . ' ' .get_user_meta($user -> ID , 'last_name' , true).'</option>';
				}
				
			}
		?>
		</select>
	</div>
	<div class="d-flex mcp_buttons">
		<button class="btn btn-outline-success" onclick="update_employee_master('<?php echo $data->id ; ?>')">بروز رسانی</button>
		<button class="btn btn-outline-danger" onclick="closeclass('mega_ajax_holder')">خروج</button>
	</div>
</div>