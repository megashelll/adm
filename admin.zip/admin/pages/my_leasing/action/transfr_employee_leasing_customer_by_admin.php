<?php 

$path = preg_replace('/accounts.*$/','',__DIR__);
include($path.'wp-load.php');

$request_body = file_get_contents('php://input');
$data = json_decode($request_body);

global $wpdb ; 
$user_tab = $wpdb -> prefix .'users';
$usermeta_tab = $wpdb -> prefix . 'usermeta';
$current_user_id = get_current_user_id() ; 

$sql = "SELECT * FROM `{$user_tab}` AS a INNER JOIN `{$usermeta_tab}` AS b ON a.ID = b.user_id WHERE b.meta_key ='{$wpdb -> prefix}capabilities' AND b.meta_value LIKE '%leasing%';" ;
$user_bosses = $wpdb ->get_results($sql);


?>

<div class="mega_capsule_popup">
	<div class="mcp_inner" style="max-width : 400px;">
		<div class="alert alert-danger" role="alert">
			شما قصد دارید که مشتریان مربوط به کارمند خود : <strong><?php echo get_user_meta($data->id , 'first_name' , true). ' ' . get_user_meta($data->id , 'last_name' , true); ?></strong> را به یکی از کارمندانی که در قسمت زیر انتخاب می کنید انقال دهید .
			<br>
			<h3 class="text-center mt-5" style="font-size : 16px;">در نظر داشته باشید این کار غیر قابل بازگشت است .</h3>
		</div>
		<hr>
		<select  name="new_employee_branches">
		<?php 			
			echo '<option selected>کاربر مد نظر خود را انتخاب کنید</option>';
			foreach($user_bosses as $key => $user){
				echo '<option  value="'.$user -> ID.'">'.get_user_meta($user -> ID , 'first_name' , true) . ' ' .get_user_meta($user -> ID , 'last_name' , true).'</option>';
			}
		?>
		</select>
	</div>
	<div class="d-flex mcp_buttons">
		<button class="btn btn-outline-success" onclick="transfer_branches_to_new_employee('<?php echo $data->id ; ?>')">بروز رسانی</button>
		<button class="btn btn-outline-danger" onclick="closeclass('mega_ajax_holder')">خروج</button>
	</div>
</div>