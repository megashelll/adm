<?php 

$path = preg_replace('/accounts.*$/','',__DIR__);
include($path.'wp-load.php');

global $wpdb;

$table = $wpdb -> prefix . 'branch_customers';
$current_user_id = get_current_user_id() ; 
$temp_url = get_template_directory_uri();
$limit = 3 ; 
$sql = "SELECT DISTINCT * FROM `{$table}` AS a LIMIT 20 , {$limit};" ;
$invoices = $wpdb -> get_results($sql);

if (current_user_can('administrator')){
	$user_sea = 'all';
}else{
	$user_sea = 'rstricted';
}

$i = 0 ; 
$ajox = array('data'=>array(),);
foreach($invoices as $key => $value){
	$customer = get_user_by('ID' , $value->customer_id);
	$order_id = $value -> order_id;
	$customer_full_name = get_user_meta($value->customer_id , 'first_name' , true) . ' ' . get_user_meta($value->customer_id , 'last_name' , true);
	$branch_zone = get_user_meta($value->branch_id , 'branch_zone' , true);
	$branch_full_name = get_user_meta($value->branch_id , 'first_name' , true) . ' ' . get_user_meta($value->branch_id , 'last_name' , true);
	$order = wc_get_order( $value -> order_id );
	$h = '';
	if ($user_sea == 'all'){	
		if (!empty($customer) & !empty($order) & $branch_full_name != ''){			
			array_push($ajox['data'], (object)[
					'order_id' => $order_id . '<br>' . $customer_full_name,
					'branch_full_name' => $branch_full_name,
					'order_total' => $order->get_total(),
					'null_item'	=> ''
			]);
			$i++ ;
		}
	}else{
		$user_master_id = get_user_meta( $value->ID , 'Create_by_masetr'  , true) ;
		if ($user_master_id == get_current_user_id()){	
		}	
	}	
}

echo json_encode($ajox);
