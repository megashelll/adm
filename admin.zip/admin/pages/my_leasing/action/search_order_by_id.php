<?php 

	$path = preg_replace('/accounts.*$/','',__DIR__);
	include($path.'wp-load.php');

	$request_body = file_get_contents('php://input');
	$data = json_decode($request_body);

	global $wpdb ; 
	if ($data){
		if (isset($data -> order_id)){


			$table = $wpdb -> prefix . 'branch_customers';
			$table_metas = $wpdb -> prefix . 'postmeta';
			$sql = "SELECT * FROM `{$table}` AS a WHERE a.order_id = '{$data -> order_id}';";
			$invoice = $wpdb -> get_results($sql);
			$invoice = $invoice[0];
			// print_r($invoice);
			
			$cid = $invoice->customer_id;
			$customer = get_user_by('ID' , $cid);
			$customer_full_name = get_user_meta($cid , 'first_name' , true) . ' ' . get_user_meta($cid , 'last_name' , true);

			$bid = $invoice->branch_id;
			$branch_zone = get_user_meta($bid , 'branch_zone' , true);
			$branch_full_name = get_user_meta($bid , 'first_name' , true) . ' ' . get_user_meta($bid , 'last_name' , true);

			$order = wc_get_order( $data -> order_id );
			if ( $order ) {
				$h = '<tr order_id="'.$data -> order_id .'" branch_id="'.$value->branch_id.'">';
					$h .= '<td>'.$data -> order_id . '<br>' . $customer_full_name.'</td>';
					$h .= '<td>'.$branch_full_name.'</td>';
					$h .= '<td>'.$order->get_total().'</td>';
					$h .= '<td>';
						$h .='<button class="bangle_form_icon btn btn-outline-success p-1 ml-2" onclick="edit_order_status(\''.$data -> order_id.'\' , \''.get_current_user_id().'\',\'mounted_box\')">';
							$h .='<img src="https://hamtaloans.com/wp-content/themes/woodmart/mega/assets/images/menu/status.png" style="width:25px ; height:25px;">';
						$h .='</button>';
						$h .='<button class="bangle_form_icon btn btn-outline-success p-1 ml-2" onclick="edit_order_items(\''.$data -> order_id.'\' , \''.get_current_user_id().'\' ,\'mounted_box\')">';
							$h .='<img src="https://hamtaloans.com/wp-content/themes/woodmart/mega/assets/images/menu/edit-246.png" style="width:25px ; height:25px;">';
						$h .='</button>';
						$h .='<button class="bangle_form_icon btn btn-outline-danger p-1 ml-2" onclick="viwe_order(\''.$data -> order_id.'\' , \''.get_current_user_id().'\' , \'mounted_box\')" >';
							$h .='<img src="https://hamtaloans.com/wp-content/themes/woodmart/mega/assets/images/menu/order.png" style="width:25px ; height:25px;">';
						$h .='</button>';
						
					$h .= '</td>';
				$h .= '</tr>';
				echo $h ; 
			}
		}	
		
	}
	