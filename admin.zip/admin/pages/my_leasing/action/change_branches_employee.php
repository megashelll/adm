<?php 
	$path = preg_replace('/accounts.*$/','',__DIR__);
	include($path.'wp-load.php');

	$request_body = file_get_contents('php://input');
	$data = json_decode($request_body);

	global $wpdb ; 
	$user_tab = $wpdb -> prefix .'users';
	$usermeta_tab = $wpdb -> prefix . 'usermeta';
	$current_user_id = get_current_user_id() ; 

	$sql = "SELECT  * FROM `{$usermeta_tab}` AS a INNER JOIN `{$user_tab}` AS b on a.user_id = b.ID WHERE a.meta_value = '{$data->id}' AND a.meta_key='branch_leasing_employee_id';"; 
	$branches = $wpdb -> get_results($sql);
	$h= '';
	$h .='<div class="mega_empoyee_branches_popup">';

		$h .='<div class="mega_ajax_holder_inner_1"></div>';
		$h .='<div class="meag_ebp_loader new_employee mega_branch_create_user container">';
			$h .='<div class="mbcu_header_title">';
				$h .='<h1>';
					$h .='<span>زیر شاخه کارمند : <strong style="color:red;">'.get_post_meta($data->id ,'first_name' , true) .' '. get_post_meta($data->id , 'last_name' , true).'</strong></span>';
					$h .='<span>[ <span>'.get_bloginfo('name').'</span> ]</span>';
				$h .='</h1>';
			$h .='</div>';

		
			$h .='<div class="mbcu_inner d-flex flex-wrap">';


				
				$h .='<table class="tabel_of_admin">';
					$h .='<thead>';
						$h .='<tr>';

							$h .='<th>';
								$h .='ردیف';
							$h .='</th>';

							$h .='<th>';
								$h .='نام';
							$h .='</th>';

							$h .='<th>';
								$h .='همراه<hr style="margin:0px;">کد ملی';
							$h .='</th>';
							
							$h .='<th>';
								$h .='ویرایش';
							$h .='</th>';

						$h .='</tr>';
					$h .='</thead>';
					$h .='<tbody>';
						$i = 1; 
						foreach($branches as $key => $value){
							$h .='<tr>';
								$h .='<td>';
									$h .=$i;
								$h .='</td>';
								
								$h .='<td>';
									$user_pid = get_user_meta( $value->ID , 'user_public_id'  , true) ;
									if ($user_pid == ''){
										$user_pid = get_user_meta( $value->ID , 'user_id_number'  , true) ;
									}
									$h .= get_user_meta($value->ID , 'first_name' , true) .' '. get_user_meta($value->ID , 'last_name' , true);
									$h .='<span>'.$user_pid .'</span>' ;
								$h .='</td>';
								
								$h .='<td>';
									$h .= $value->user_login;
								$h .='</td>';

								$h .='<td>';
									$h .='<button class="mega_admin_button btn btn-outline-dark" onclick="change_user_owner(\''.$value->ID.'\' )">تغییر مجموعه</button>';
									$h .='<button class="mega_admin_button btn btn-outline-success" onclick="user_invoices(\''.$value->ID.'\' )">فاکتورها</button>';
									$h .='<div style="width:100px ; display:inline-block;"></div>';
									$h .='<button class="mega_admin_button btn btn-outline-danger" onclick="remove_user(\''.$value->ID.'\' )">حذف کاربر</button>';
									
								$h .='</td>';
								
							$h .='</tr>';

						}
					$h .='</tbody>';
				$h .='</table>';

				$h .='<div class="d-flex mcp_buttons">';
					$h .='<button class="btn btn-outline-success" onclick="update_employee_master('.$data -> id.')">بروز رسانی</button>';
					$h .='<button class="btn btn-outline-danger" onclick="closeclass(\'mega_ajax_holder\')">خروج</button>';
				$h .='</div>';
			$h .='</div>';

		$h .= '</div>';

	$h .= '</div>';

	echo $h ;