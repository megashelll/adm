<?php 

	$path = preg_replace('/accounts.*$/','',__DIR__);
	include($path.'wp-load.php');

	$request_body = file_get_contents('php://input');
	$data = json_decode($request_body);
	function update_order_status_branch(){
		global $wpdb ; 
		$id  = $data->order_id ;
		$status = $data ->status ;
		$table_order	= $wpdb -> prefix .'branch_customers';
		$data_table = ['order_status' => $status];
		$where = ['order_id' => $id];
		$wpdb ->update($table_order ,$data_table ,$where);
	}
	
	if (update_post_meta($data->order_id , 'mega_status_of_order' , $data->status)){
		echo $data->status;
		update_order_status_branch($data->order_id , $data->status);
	}else{
		echo 'faild';
	}
?>
