<?php 

	$path = preg_replace('/accounts.*$/','',__DIR__);
include($path.'wp-load.php');

	$request_body = file_get_contents('php://input');
	$data = json_decode($request_body);

	global $wpdb ; 
	$user_tab = $wpdb -> prefix .'users';
	$usermeta_tab = $wpdb -> prefix . 'usermeta';
	$current_user_id = get_current_user_id() ; 

	$sql = "SELECT  * FROM `{$usermeta_tab}` AS a INNER JOIN `{$user_tab}` AS b on a.user_id = b.ID WHERE a.meta_value = '{$data->id}' AND a.meta_key='branch_leasing_employee_id';"; 
	$branches = $wpdb -> get_results($sql);

	foreach($branches as $key => $value){	
		update_user_meta($value->ID , 'branch_leasing_employee_id' , $data -> new_id);
	}

