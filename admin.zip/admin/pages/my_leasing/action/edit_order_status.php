<?php 

	$path = preg_replace('/accounts.*$/','',__DIR__);
	include($path.'wp-load.php');

	$request_body = file_get_contents('php://input');
	$data = json_decode($request_body);

	global $wpdb ; 
	$os = get_post_meta( $data->order_id , 'mega_status_of_order' , true) ;
	if ($os == 'order_rejected'){
		$os = 'سفارش مردود شده';
		$os_class = 'alert alert-danger';
	}elseif($os == 'order_pending'){
		$os='سفارش در حال تأیید';
		$os_class = 'alert alert-info';
	}elseif($os == 'order_approved'){
		$os='سفارش تأیید شده ';
		$os_class = 'alert alert-success';
	}else{
		$os='سفارش در حال تأیید';
		$os_class = 'alert alert-info';
	}
	?>

	<div style="mega_order_status_holder d-flex flex-wrap">
		<div class="popup_close_button position-absolute">
			<button onclick="closetheareaof('mounted_box')">X close</button>
		</div>
		<div class="<?php echo $os_class; ?> text-center" role="alert">
			وضعیت سفارش در این لحظه بر روی حالت </br>
			<h3><?php echo $os; ?></h3>
			قرار دارد	
		</div>
		<div class="mosh_items" order_id ="<?php echo $data->order_id; ?>" m_target="mounted_box">
			<button onclick="update_order_to_new_status('order_rejected' , 'mounted_box' , '<?php echo $data->order_id; ?>')" class="mpsh_buttom btn btn-danger" value_m = '001'>مردود شود</button>
			<button onclick="update_order_to_new_status('order_pending' , '0' , '<?php echo $data->order_id; ?>')" class="mpsh_buttom btn btn-info" value_m = '002'>در انتظار بماند</button>
			<button onclick="update_order_to_new_status('order_approved' , 'mounted_box' , '<?php echo $data->order_id; ?>')" class="mpsh_buttom btn btn-success" value_m = '003'>تایید شود</button>
		</div>
		<div class="mosh_action_button"></div>
	</div>
	