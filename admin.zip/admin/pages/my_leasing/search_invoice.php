<?php 
// تنظیمات اولیه مثل قبل
global $wpdb;
$table = $wpdb->prefix . 'branch_customers';
$table_metas = $wpdb->prefix . 'postmeta';
$current_user_id = get_current_user_id(); 
$temp_url = get_template_directory_uri();
$limit = 20;
$page = 0;

// استایل‌های جدید با تاکید بر عرض کامل
echo '<style>
    .mounted_box {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 1050;
    }
    
    .mounted_box.active_popup {
        display: flex;
        justify-content: center;
        align-items: center;
    }
    
    .container-fluid {
        padding-left: 1rem !important;
        padding-right: 1rem !important;
        max-width: 100% !important;
    }
    
    .card {
        margin-left: -1rem;
        margin-right: -1rem;
        border-radius: 0;
        border-left: none;
        border-right: none;
    }
    
    .search-highlight {
        background-color: #fff3cd;
        padding: 0.2rem;
        border-radius: 3px;
    }
    
    .table-responsive {
        min-height: 400px;
    }
    
    .pagination-custom .page-link {
        border: none;
        padding: 0.5rem 1rem;
        margin: 0 0.2rem;
    }
    
    .pagination-custom .page-item.active .page-link {
        background-color: #0d6efd;
        color: white;
    }

    @media (max-width: 768px) {
        .container-fluid {
            padding-left: 0 !important;
            padding-right: 0 !important;
        }
        
        .card {
            margin-left: 0;
            margin-right: 0;
        }
    }
</style>';

// Modal Container
echo '<div class="mounted_box position-fixed off"></div>';

// Main Container - با عرض کامل
echo '<div class="container-fluid px-0">';

    // Search Card - با عرض کامل
    echo '<div class="card shadow-sm mb-4">
        <div class="card-body px-md-4">
            <div class="row g-3 align-items-center">
                <div class="col-md-8">
                    <div class="input-group">
                        <span class="input-group-text bg-light">
                            <i class="bi bi-search"></i>
                        </span>
                        <input type="number" 
                               name="search_order_id" 
                               class="form-control" 
                               placeholder="شماره فاکتور را وارد کنید..."
                               aria-label="شماره فاکتور">
                    </div>
                    <div class="form-text text-muted">
                        <i class="bi bi-info-circle me-1"></i>
                        تنها کد فاکتور را وارد کنید
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <button class="btn btn-primary d-inline-flex align-items-center" 
                            onclick="search_order(\''.$current_user_id.'\', \'mega_list_of_orders\')">
                        <i class="bi bi-search me-2"></i>
                        جستجو
                    </button>
                </div>
            </div>
        </div>
    </div>';

    // Results Card - با عرض کامل
    echo '<div class="card shadow-sm">
        <div class="card-header bg-light py-3">
            <div class="px-md-4 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <i class="bi bi-receipt me-2 fs-4"></i>
                    <div>
                        <h5 class="mb-0">آخرین فاکتورها</h5>
                        <small class="text-muted">'.get_bloginfo('name').'</small>
                    </div>
                </div>
                <span class="badge bg-primary">۲۰۰ مورد</span>
            </div>
        </div>
        
        <div class="card-body px-md-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>سفارش مشتری</th>
                            <th>نام نماینده</th>
                            <th>جمع کل</th>
                            <th>گزینه‌ها</th>
                        </tr>
                    </thead>
                    <tbody class="mega_list_of_orders">';

                    // Generate Table Rows
                    if (isset($invoices) && !empty($invoices)) {
                        foreach ($invoices as $value) {
                            if (current_user_can('administrator') || 
                                get_user_meta($value->ID, 'Create_by_masetr', true) == get_current_user_id()) {
                                
                                $customer = get_user_by('ID', $value->customer_id);
                                $customer_full_name = get_user_meta($value->customer_id, 'first_name', true) . ' ' . 
                                                    get_user_meta($value->customer_id, 'last_name', true);
                                $branch_full_name = get_user_meta($value->branch_id, 'first_name', true) . ' ' . 
                                                  get_user_meta($value->branch_id, 'last_name', true);
                                $order = wc_get_order($value->order_id);
                                
                                if (!empty($customer) && !empty($order) && !empty($branch_full_name)) {
                                    echo '<tr order_id="'.$value->order_id.'" branch_id="'.$value->branch_id.'">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="bg-light rounded-circle p-2 me-3">
                                                    <i class="bi bi-person"></i>
                                                </div>
                                                <div>
                                                    <div class="fw-bold">#'.$value->order_id.'</div>
                                                    <small class="text-muted">'.$customer_full_name.'</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>'.$branch_full_name.'</td>
                                        <td>'.wc_price($order->get_total()).'</td>
                                        <td>
                                            <div class="btn-group">
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-primary" 
                                                        data-bs-toggle="tooltip" 
                                                        data-bs-placement="top" 
                                                        title="مشاهده جزئیات">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-secondary"
                                                        data-bs-toggle="tooltip" 
                                                        data-bs-placement="top" 
                                                        title="چاپ فاکتور">
                                                    <i class="bi bi-printer"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>';
                                }
                            }
                        }
                    }

    echo '</tbody>
                </table>
            </div>';

            // Pagination
            if (isset($_GET['pn'])) {
                echo '<div class="px-md-4 mt-4">
                    <nav aria-label="صفحه‌بندی">
                        <ul class="pagination pagination-custom justify-content-center mb-0">';
                
                if ($currnt_page > 1) {
                    echo '<li class="page-item">
                        <a class="page-link" href="'.get_site_url().'/my-account/?admin=search_invoice&pn='.($currnt_page-1).'">
                            <i class="bi bi-chevron-right me-1"></i>
                            قبلی
                        </a>
                    </li>';
                }
                
                echo '<li class="page-item">
                    <a class="page-link" href="'.get_site_url().'/my-account/?admin=search_invoice&pn='.($currnt_page+1).'">
                        بعدی
                        <i class="bi bi-chevron-left ms-1"></i>
                    </a>
                </li>';
                
                echo '</ul>
                    </nav>
                </div>';
            }

    echo '</div>
    </div>
</div>';

// Initialize Tooltips
echo '<script>
    document.addEventListener("DOMContentLoaded", function() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll(\'[data-bs-toggle="tooltip"]\'));
        var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
</script>';
?>