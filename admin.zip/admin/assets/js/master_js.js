let ajax_url = 'https://hamtaloans.com/accounts/functions/inc/';
function search_customer_by_name(target){
	var user_name = jQuery('[name="search_user_by_name"]').val();
	jQuery.ajax({
		url: "https://hamtaloans.com/wp-content/themes/woodmart/mega/inc/pages/account/admin/pages/my_customers/action/search_customer.php",
		type: 'post', // performing a POST request
		data : {
			searh : user_name
		},
		success: function(result){
			jQuery('.'+target).html(result);
		}
	});
}



function add_new_zone(){
	jQuery.ajax({
		url: "https://hamtaloans.com/accounts/admin/inc/add_new_zone.php",
		type: 'post',
		data : {
			zone_name : jQuery('[name="zone_name"]').val(),
			zone_states : jQuery('[name="zone_states"]').val(),
			leasing_employee : jQuery('[name="leasing_employee"]').val()
		},
		success: function(result){
			if (result == 'done'){
				alert('منطقه جدید به سامانه افزوده شد');
				location.reload();
			}else{
				
			}
			jQuery('.result_of_search_customer').html(result);
		}
	});
}



function save_zone(id){
	jQuery.ajax({
		url: "https://hamtaloans.com/accounts/admin/inc/save_zone.php",
		type: 'post',
		data : {
			zone_id : id,
			zone_name : jQuery('[name="zone_name"]').val(),
			zone_states : jQuery('[name="zone_states"]').val(),
			leasing_employee : jQuery('[name="leasing_employee"]').val()
		},
		success: function(result){
			if (result == 'done'){
				alert('منطقه به روز رسانی شد');
				location.reload();
			}else{
				
			}
			
		}
	});
}




function remove_zone_by_master(id){

	jQuery.ajax({
		url: "https://hamtaloans.com/accounts/admin/inc/remove_zone_by_master.php",
		type: 'post', // performing a POST request
		data : {
			post_id : id
		},
		success: function(result){
			if (result == 'yes'){
				alert("حذف موفقیت آمیز بود.");
				location.reload();
			}else{
				alert('حذف نا موفق بود')
			}
			
		}
	});
}


function add_new_employee(type){
	var mm = ''; 
	if (type == null){
		mm = 'customer';
		type = '4';
	}else if (type == '1'){
		mm = 'leasing';
	}else if( type == '2' ){
		mm='enterprise_leasing';
	}else if (type == '3'){
		mm = 'branch';
	}else if (type == '4'){
		mm = 'customer';
	}

	let omg ={
		"first_name"			: jQuery('[name="first_name"]').val(),
		"last_name"				: jQuery('[name="last_name"]').val(),
		"user_mobile"			: jQuery('[name="user_mobile"]').val(),
		"user_id_number"		: jQuery('[name="user_id_number"]').val(),
		"user_type"				: mm ,
	}
	
	var xmlhttp = new XMLHttpRequest();
	
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
		  jQuery('.new_employee').html(this.response);
      }
    };

	if (type == '1'){
		var ac_path = 'https://hamtaloans.com/accounts/admin/pages/my_leasing/action/';
    	xmlhttp.open("POST", ac_path+"new_user_leasing_ajax.php");
	}else if (type == '2'){
		var ac_path = 'https://hamtaloans.com/accounts/admin/pages/my_leasing/action/';
    	xmlhttp.open("POST", ac_path+'new_user_leasing_ajax.php');
	}else if (type == '3'){
		var ac_path = 'https://hamtaloans.com/accounts/admin/ajax/inc/pages/account/admin/pages/my_branch/action/';		
    	xmlhttp.open("POST", ac_path+"new_user_leasing_ajax.php");
	}else if (type == '4'){
		var ac_path = 'https://hamtaloans.com/accounts/admin/ajax/inc/pages/account/admin/pages/my_customer/action/';		
    	xmlhttp.open("POST", ac_path+"new_user_leasing_ajax.php");
	}else{
    	xmlhttp.open("POST", 'https://hamtaloans.com/accounts/ajax/new_user.php');
	}

    xmlhttp.send(JSON.stringify(omg));

}


function add_new_branch_ajax(id){
	let omg ={
		'child_of'					: 'admin' , 
		'maker_branch_id'			: id,
		'macker_role'				: 'admin',
		'user_id_number' 			: jQuery('[name="branch_id_number"]').val(),
		'user_state'				: jQuery('[name="branch_state"]').val(),
		'user_city'					: jQuery('[name="branch_city"]').val(),
		'user_address'				: jQuery('[name="branch__address"]').val(),
		'user_phone'				: jQuery('[name="user_phone"]').val(),
		'user_mobile'				: jQuery('[name="branch_mobile"]').val(),
		'first_name' 				: jQuery('[name="branch_first_name"]').val(),
		'last_name'	 				: jQuery('[name="branch_last_name"]').val(),
		'zip_postal_code'			: jQuery('[name="branch_zip_postal_code"]').val(),
		'branch_serial_number'		: jQuery('[name="branch_serial_number"]').val(),
		"branch_contract_serial"	: jQuery('[name="branch_contract_serial"]').val(),
		'user_phone_number'			: jQuery('[name="user_mobile"]').val(),
		'show_admin_bar_front' 		: 'false',
		'role' 						: 'branch',
		"creator"					: id,
	}
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
		  jQuery('.mega_admin_create_user').before().append(this.response);
      }
    };
	var ac_path = 'https://hamtaloans.com/accounts/admin/ajax/inc/pages/account/admin/pages/my_branch/action/';
    xmlhttp.open("POST", ac_path+"new_user_branch_ajax.php");
    xmlhttp.send(JSON.stringify(omg));

}


function search_order(id , target){
	let omg ={
		"id" 		: id,
		"order_id" 	: jQuery('[name="search_order_id"]').val(),
	}
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			jQuery('.'+target).html(this.response)
		}
	}
	var ac_path = 'https://hamtaloans.com/accounts/admin/pages/my_leasing/action/search_order_by_id.php';
    xmlhttp.open("POST", ac_path);
    xmlhttp.send(JSON.stringify(omg));
}

jQuery('[name="search_order_id"]').on( "keyup", function() {
 	let omg ={
		"order_id" 	: jQuery('[name="search_order_id"]').val(),
	}
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			jQuery('.mega_list_of_orders').html(this.response)
		}
	}
	var ac_path = 'https://hamtaloans.com/accounts/admin/pages/my_leasing/action/search_order_by_id.php';
    xmlhttp.open("POST", ac_path);
    xmlhttp.send(JSON.stringify(omg));
} );


function update_order_to_new_status(status , target , order_id){
	let omg ={
		"order_id" 	: order_id,
		"status"	: status 
	}
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			if (this . response == 'order_rejected'){
				jQuery('.'+target).html('');
				alert("وضعیت سفارش  :‌ "+order_id+" به مردود شده تغییر کرد .");
				jQuery('.'+target).removeClass('active_popup');
			}else if (this . response == 'order_pending'){
				jQuery('.'+target).html('');
				alert("وضعیت سفارش  :‌ "+order_id+" به در حال تایید تغییر کرد .");
				jQuery('.'+target).removeClass('active_popup');
			}else if (this . response == 'order_approved'){
				jQuery('.'+target).html('');
				alert("وضعیت سفارش  :‌ "+order_id+" به در تایید شده تغییر کرد .");
				jQuery('.'+target).removeClass('active_popup');
			}else if (this . response == 'faild'){
				alert('دوباره تلاش کنید');
			}
		}
	}
	var ac_path = 'https://hamtaloans.com/wp-content/themes/woodmart/mega/inc/pages/account/admin/pages/my_leasing/action/update_order_to_new_status.php';
    xmlhttp.open("POST", ac_path);
    xmlhttp.send(JSON.stringify(omg));
}


function edit_order_status(order_id , uid , target){
	let omg ={
		"order_id" 	: order_id,
		'uid'		: uid ,
		'target'	: target
	}
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			jQuery('.'+target).html(this.response);
			jQuery('.'+target).addClass('active_popup');
		}
	}
	var ac_path = 'https://hamtaloans.com/wp-content/themes/woodmart/mega/inc/pages/account/admin/pages/my_leasing/action/edit_order_status.php';
    xmlhttp.open("POST", ac_path);
    xmlhttp.send(JSON.stringify(omg));
}






function edit_order_items(order_id , editor , target){
	let omg ={
		"order_id" 	: order_id,
		"editor_id"	: editor , 
		"target"	: target 
	}
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			jQuery('.'+target).html(this . response);
			jQuery('.'+target).addClass('active_popup');
		}
	}
	var ac_path = 'https://hamtaloans.com/wp-content/themes/woodmart/mega/inc/pages/account/admin/pages/my_leasing/action/edit_order_view.php';
    xmlhttp.open("POST", ac_path);
    xmlhttp.send(JSON.stringify(omg));
}

jQuery(document).on("load" , function(){
	var a=jQuery('.mpi_quantity').attr('qty');
	if (a == 10){
		jQuery('.mpi_quantity').removeClass('normal_ud');
		jQuery('.mpi_quantity').addClass('no_up');
	}else if(a < 10 & a >1){
		jQuery('.mpi_quantity').addClass('normal_ud');
		jQuery('.mpi_quantity').addClass('no_down');
	}else{
		jQuery('.mpi_quantity').removeClass('no_up');
		jQuery('.mpi_quantity').removeClass('no_down');
		jQuery('.mpi_quantity').addClass('normal_ud');
	}
})
jQuery('.plus_qty_in_mpi').click(function(){
	
})


function save_add_new_employee_to_zone (id){
	var ajurl = "https://hamtaloans.com/accounts/admin/inc/add_new_employee_to_zone.php" ; 
	var ajcond = 'save';
	var checkboxes = document.querySelectorAll('input[name="options[]"]:checked');
    var selectedValues = [];

    // جمع‌آوری گزینه‌های انتخاب‌شده
    checkboxes.forEach(function(checkbox) {
      selectedValues.push(checkbox.value);
    });
	jQuery.ajax({
		url: ajurl,
		type: 'post', // performing a POST request
		data : {
			post_id : id ,
			load : ajcond ,
			employee : jQuery('[name="employee"]').val(),
			options :selectedValues
		},
		success: function(result){
			alert(result)
		}
	});
}


function load_modal_data (cond , id){
	if (cond!=''){
		if (cond == 'add_new_employee_to_zone'){
			var ajurl = "https://hamtaloans.com/accounts/admin/inc/add_new_employee_to_zone.php" ; 
			var ajcond = 'form';
			jQuery('#modal_body').html('');
			jQuery('#save_the_dialog').attr('onclick', "save_add_new_employee_to_zone('"+id+"')");
		}
		
	}

	jQuery.ajax({
		url: ajurl,
		type: 'post', // performing a POST request
		data : {
			post_id : id ,
			load : ajcond 
		},
		success: function(result){
			jQuery('#modal_body').html(result);
		}
	});
}








function save_zone(zone_id) {
    // نمایش لودینگ روی دکمه
    const saveButton = jQuery('[onclick="save_zone(\'' + zone_id + '\')"]');
    saveButton.prop('disabled', true)
             .html('<span class="spinner-border spinner-border-sm me-2"></span>در حال ذخیره...');

    // جمع‌آوری داده‌ها از فرم
    const formData = {
        zone_id: zone_id,
        zone_name: jQuery('input[name="zone_name"]').val(),
        zone_states: jQuery('select[name="zone_states"]').val(),
        leasing_employee: jQuery('select[name="leasing_employee"]').val()
    };

    // ارسال درخواست Ajax
    jQuery.ajax({
        url: 'https://hamtaloans.com/accounts/admin/inc/save_zone.php',
        type: 'POST',
        data: formData,
        success: function(response) {
            if(response === 'done') {
                // نمایش پیام موفقیت
                jQuery('.save_zone_results').html(`
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-check-circle me-2"></i>
                            منطقه با موفقیت بروزرسانی شد
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `);

                // ریدایرکت بعد از 2 ثانیه
                setTimeout(function() {
                    
                }, 2000);
            } else {
                // نمایش خطا
                jQuery('.save_zone_results').html(`
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            خطا در بروزرسانی اطلاعات
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `);
            }
        },
        error: function() {
            // نمایش خطای ارتباط با سرور
            jQuery('.save_zone_results').html(`
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        خطا در ارتباط با سرور
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            `);
        },
        complete: function() {
            // بازگرداندن دکمه به حالت اولیه
            saveButton.prop('disabled', false)
                     .html('<i class="bi bi-check2-circle me-2"></i>ذخیره تغییرات');
        }
    });
}