		
		<script src="https://hamtaloans.com/accounts/lib/bootstrap-5.3.3/dist/js/bootstrap.bundle.min.js"></script>
		<script src="https://hamtaloans.com/accounts/admin/assets/js/master_js.js"></script>
		
	</body>
</html>