<?php 
$path = preg_replace('/accounts.*$/','',__DIR__);
include($path.'wp-load.php');

if (isset($_POST['post_id'])){
	if (is_user_logged_in()){
		$trashed_post = wp_delete_post($_POST['post_id'] , true);
		if ($trashed_post !== false ) {
			echo "yes";
		} else {
			echo "no";
		}
	}else{
		
	}
}