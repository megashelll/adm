<?php 
$path = preg_replace('/accounts.*$/','',__DIR__);
include($path.'wp-load.php');

if (isset($_POST)){
	if (isset($_POST['zone_id'])){

		if (isset($_POST['zone_name'])){
			if (isset($_POST['zone_states'])){
				if (isset($_POST['leasing_employee'])){

					$leasing_employee 	= $_POST['leasing_employee'];
					$zone_states		= $_POST['zone_states'];
					$zone_name 			= $_POST['zone_name'];

					$post_data = array(
						'ID'           			=> $_POST['zone_id'],
						'post_title' 			=> $zone_name,
						'post_content' 			=> '',
						'post_type' 			=> 'zone_area',
						'post_status' 			=> 'publish',
						'meta_input'   			=> array(
							'zone_states' 		=> $zone_states,
							'leasing_employee'  => $leasing_employee,
							'zone_master'  		=> $leasing_employee
						),
					);
					wp_update_post( $post_data );
					if(!is_wp_error($post_id)){
						echo 'done';
					}else{
						echo json_encode($post_id->get_error_message());
					}

				}else{

				}
			}else{

			}
		}else{

		}
	}
		
}else{
	
}