<?php 
$path = preg_replace('/accounts.*$/','',__DIR__);
include($path.'wp-load.php');

global $wpdb ; 
$data = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/state.json'));
$city_data = json_decode(file_get_contents('https://hamtaloans.com/accounts/lib/iran_state_city/city.json'));

$sql = "SELECT user_id FROM `edu_usermeta` WHERE `meta_key` LIKE 'edu_capabilities' AND `meta_value` LIKE '%leasing%'";
$leasings = $wpdb->get_results($sql);

$h = '';

if (isset($_POST['load'])){
	if ($_POST['load'] == 'form'){
		if (isset($_POST['post_id'])){
			$zone_id =$_POST['post_id'] ; 
			$zone_state = get_post_meta($zone_id , 'zone_states' , true);
			$manager = get_post_meta($zone_id , 'zone_master' , true);

			if ($manager){
				$man_count = 1;
				foreach($manager as $man ){
					if ($man_count == 1){
						$man_id = $man ; 
					}
				}

				if ($man_id){
					echo '<div class="col-12 bg-dark text-white mb-3 rounded p-3">';
						echo '<div class="zone_name col-3">نام منطقه : '.get_the_title($zone_id).'</div>';
						echo '<div class="zone_manager col-3">مدیر منطقه : ' .'<span><strong>'.get_user_meta($man_id , 'first_name' , true) . ' ' .get_user_meta($man_id , 'last_name' , true) .'</strong></span></div>';
					echo '</div>';
				}else{
					echo '<div class="col-12 bg-dark text-white mb-3 rounded">';
						echo 'مدیر منطقه : ' .'<span><strong>برای این منطقه مدیری انتخاب نشده است</strong></span>';
					echo '</div>';
				}

				$h ='<div class="col-12 mt-2 mb-0 p-3 bg-light text-dark">';
					$h .='<label>انتخاب کارمند</label>';
					$h .='<div class="p-2 pb-0">';
						$h .='<select  name="employee" placeholder="انتخاب کارمند" class="bg-white text-dark">';
							foreach ($leasings as $ls) {
								$user = get_user_by('ID', $ls->user_id);
								if ($user) {
									$h .= '<option value="' . $user->ID . '">' . $user->data->display_name . '</option>';
								}
							}

						$h .= '</select>';
					$h .='</div>';
				$h .='</div>';
				
				// print_r($zone_state);
				$h .= '<div class="col-12 d-flex flex-wrap bg-light mt-0 mb-2 p-2">';
					foreach($data as $prov){
						if (in_array($prov->id, $zone_state)){
							$h .='<div class="col-2 d-flex flex-wrap p-3 ">';
								$h .='<div class="d-flex w-100 shadow-sm bg-white text-dark border rounded p-2">';
									$h .='<input type="checkbox" id="option1" name="options[]" value="'.$prov->id.'" >';
								$h .='<label>'.$prov->name.'</label>';
								$h .='</div>';
							$h .='</div>';
						}
					}
				$h .='</div>';
				$h .='<input type="hidden" name="zone_master_id" value="'.$zone_id.'">';
				echo $h ; 
			}
		}else{
			echo 'منطقه ست نشده است ';
		}
	}elseif($_POST['load'] == 'save'){
		$old_employee = get_post_meta($_POST['post_id'] , 'leasing_employee' , true); 
		
		if (!in_array($_POST['employee'] , $old_employee)){
			array_push($old_employee , $_POST['employee']);
			update_post_meta($_POST['post_id'] , 'leasing_employee' ,$old_employee);
		}else{

		}

		update_user_meta($_POST['employee'] , 'my_zone_state_'.$_POST['post_id'] , $_POST['options']);
		

	}else{
		echo 'دیتا کامل نیست ';
	}
	$sql = "SELECT user_id FROM `edu_post_meta` WHERE `meta_key` LIKE 'zone_empo' AND `post_id` LIKE '{$zone_id}'";
	$zone_employees = $wpdb->get_results($sql);
}else{
	echo 'دیتا لود نشده است';
}